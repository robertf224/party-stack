import type { MetaLinkType } from "@party-stack/ontology";
import type { ObjectTypeFullMetadata } from "@osdk/foundry.ontologies";
export declare function convertFoundryMetaLinkTypes(objectTypes: ObjectTypeFullMetadata[]): MetaLinkType[];
//# sourceMappingURL=convertMetaLinkType.d.ts.map