import type { MetaObjectType } from "@party-stack/ontology";
import type { ObjectTypeFullMetadata } from "@osdk/foundry.ontologies";
export declare function convertFoundryMetaObjectType(metadata: ObjectTypeFullMetadata): MetaObjectType;
//# sourceMappingURL=convertMetaObjectType.d.ts.map