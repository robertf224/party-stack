export {};
//# sourceMappingURL=actionTypeCollectionOptions.test.d.ts.map