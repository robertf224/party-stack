import type { QueryFunctionTypeDef } from "@party-stack/ontology";
import type { QueryTypeV2 } from "@osdk/foundry.ontologies";
export declare function convertFoundryMetaQueryFunctionType(query: QueryTypeV2): QueryFunctionTypeDef;
//# sourceMappingURL=convertMetaQueryFunctionType.d.ts.map