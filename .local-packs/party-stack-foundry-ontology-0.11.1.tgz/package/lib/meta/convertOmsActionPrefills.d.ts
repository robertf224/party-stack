import type { ActionParameterDef, ActionParameterPrefill } from "@party-stack/ontology";
export declare function convertOmsActionParameterPrefills(actionType: unknown, parameters: ActionParameterDef[]): Map<string, ActionParameterPrefill[]>;
//# sourceMappingURL=convertOmsActionPrefills.d.ts.map