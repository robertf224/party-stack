export {};
//# sourceMappingURL=entityCollectionOptions.test.d.ts.map