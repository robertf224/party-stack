export {};
//# sourceMappingURL=foundryPrivateApiUrls.test.d.ts.map