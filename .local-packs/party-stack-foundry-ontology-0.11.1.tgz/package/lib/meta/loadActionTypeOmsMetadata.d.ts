import { ontologyMetadataApi } from "@bobbyfidz/oms";
import type { OntologyClient } from "@party-stack/foundry-client";
export type ActionTypeOmsMetadata = ontologyMetadataApi.IActionType;
export declare function loadActionTypeOmsMetadata(client: OntologyClient, actionTypeRids: string[]): Promise<Map<string, ActionTypeOmsMetadata>>;
//# sourceMappingURL=loadActionTypeOmsMetadata.d.ts.map