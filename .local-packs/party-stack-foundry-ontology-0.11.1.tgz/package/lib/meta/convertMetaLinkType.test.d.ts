export {};
//# sourceMappingURL=convertMetaLinkType.test.d.ts.map