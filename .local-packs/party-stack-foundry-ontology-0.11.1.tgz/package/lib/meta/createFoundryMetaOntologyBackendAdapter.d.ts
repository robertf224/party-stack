import type { OntologyClient } from "@party-stack/foundry-client";
import type { OntologyBackendAdapter } from "@party-stack/ontology";
export interface CreateFoundryMetaOntologyBackendAdapterOpts {
    client: OntologyClient;
}
export declare function createFoundryMetaOntologyBackendAdapter(opts: CreateFoundryMetaOntologyBackendAdapterOpts): OntologyBackendAdapter;
//# sourceMappingURL=createFoundryMetaOntologyBackendAdapter.d.ts.map