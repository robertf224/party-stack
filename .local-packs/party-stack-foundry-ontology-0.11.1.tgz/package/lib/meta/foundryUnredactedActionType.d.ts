import { type OntologyClient } from "@party-stack/foundry-client";
/**
 * Party-owned view of Foundry OMS unredacted action-type metadata.
 *
 * Generic `MetaActionType` (via the ActionType collection / `pull()`) already covers portable
 * declarative logic and public parameter types. Structures that only exist on the unredacted OMS
 * wire — layout, submission criteria, and nested parameter validations/prefills — are exposed
 * here as the explicit Foundry-specific escape hatch.
 */
export type FoundryActionStaticValue = {
    type: "string";
    string: string;
} | {
    type: "boolean";
    boolean: boolean;
} | {
    type: "integer";
    integer: number;
} | {
    type: "long";
    long: number | string;
} | {
    type: "double";
    double: number;
} | {
    type: "date";
    date: string;
} | {
    type: "timestamp";
    timestamp: string;
} | {
    type: "null";
};
export type FoundryActionParameterPrefill = {
    type: "staticValue";
    staticValue: FoundryActionStaticValue;
} | {
    type: "objectParameterPropertyValue";
    objectParameterPropertyValue: {
        parameterId: string;
        propertyTypeId: string;
    };
} | {
    type: "objectQueryPrefill";
    objectQueryPrefill: {
        objectSet: Record<string, unknown>;
    };
} | {
    type: string;
    [key: string]: unknown;
};
export interface FoundryActionParameterValidationNode {
    /** Nested default validation block from OMS wire. */
    defaultValidation?: FoundryActionParameterValidationNode;
    validation?: {
        allowedValues?: unknown;
        defaultValue?: unknown;
        [key: string]: unknown;
    };
    display?: {
        prefill?: FoundryActionParameterPrefill | null;
        [key: string]: unknown;
    };
    prefill?: FoundryActionParameterPrefill | null;
    defaultValue?: unknown;
    structFieldValidations?: Record<string, FoundryActionParameterValidationNode>;
    [key: string]: unknown;
}
export interface FoundryUnredactedActionTypeMetadata {
    rid: string;
    /** Present when the OMS payload includes action metadata.apiName. */
    apiName?: string;
    parameterValidations: Record<string, FoundryActionParameterValidationNode>;
    /**
     * Remaining unredacted OMS `actionTypeLogic` payload (rules, submission criteria, etc.).
     * Intentionally opaque — Streamline interprets shapes it understands.
     */
    actionTypeLogic?: Record<string, unknown>;
    /** Remaining unredacted OMS `metadata` payload. */
    metadata?: Record<string, unknown>;
}
/**
 * Loads unredacted OMS action-type metadata by RID.
 *
 * Requires the `ontology:view-unredacted-action-type` scope. Uses OntologyClient's
 * `baseUrl` / `tokenProvider` / `fetch` only — no OSDK private context access.
 */
export declare function getFoundryUnredactedActionTypeMetadata(client: OntologyClient, actionTypeRid: string): Promise<FoundryUnredactedActionTypeMetadata | undefined>;
//# sourceMappingURL=foundryUnredactedActionType.d.ts.map