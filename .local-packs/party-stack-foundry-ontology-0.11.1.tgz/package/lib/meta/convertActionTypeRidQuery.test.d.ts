export {};
//# sourceMappingURL=convertActionTypeRidQuery.test.d.ts.map