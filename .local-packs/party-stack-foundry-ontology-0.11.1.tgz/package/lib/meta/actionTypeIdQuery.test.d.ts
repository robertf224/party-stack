export {};
//# sourceMappingURL=actionTypeIdQuery.test.d.ts.map