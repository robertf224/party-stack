import type { ActionTypeDef, MetaActionType } from "@party-stack/ontology";
import type { ActionTypeOmsMetadata } from "./loadActionTypeOmsMetadata.js";
import type { ActionTypeFullMetadata } from "@osdk/foundry.ontologies";
export declare function getFoundryActionOverrideParameterMapping(actionType: ActionTypeDef): {
    uuidByParameterName: Map<string, string>;
    nowParameterName?: string;
};
export declare function convertFoundryMetaActionType(actionType: ActionTypeFullMetadata, omsMetadata?: ActionTypeOmsMetadata): MetaActionType;
//# sourceMappingURL=convertMetaActionType.d.ts.map