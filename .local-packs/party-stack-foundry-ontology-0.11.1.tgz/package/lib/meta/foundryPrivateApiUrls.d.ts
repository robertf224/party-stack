/** Builds a Foundry private/API URL from an install base URL without leaking OSDK client internals. */
export declare function getFoundryPrivateApiUrl(baseUrl: string, path: string): URL;
export declare function getOntologyMetadataBulkLoadEntitiesUrl(baseUrl: string): URL;
//# sourceMappingURL=foundryPrivateApiUrls.d.ts.map