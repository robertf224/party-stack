import { type ActionTypeV2 } from "@osdk/foundry.ontologies";
import { QueryClient } from "@tanstack/query-core";
import type { OntologyClient } from "@party-stack/foundry-client";
import type { OntologyCollectionOptions } from "@party-stack/ontology";
export interface ActionTypeCollectionOpts {
    client: OntologyClient;
    queryClient?: QueryClient;
}
export declare function isNotDeclarativeActionType(actionType: ActionTypeV2): boolean;
export declare function actionTypeCollectionOptions(opts: ActionTypeCollectionOpts): OntologyCollectionOptions;
//# sourceMappingURL=actionTypeCollectionOptions.d.ts.map