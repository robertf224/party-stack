import type { OntologyClient } from "@party-stack/foundry-client";
import type { MetaLinkType, MetaObjectType, MetaValueType, OntologyCollectionOptions } from "@party-stack/ontology";
type MetaEntity = {
    entityType: "ObjectType";
    entity: MetaObjectType;
} | {
    entityType: "ValueType";
    entity: MetaValueType;
} | {
    entityType: "LinkType";
    entity: MetaLinkType;
};
export interface MetaEntityStoreOpts {
    client: OntologyClient;
}
export declare function createMetaEntityCollection(opts: MetaEntityStoreOpts): import("@tanstack/db").Collection<MetaEntity, string | number, import("@tanstack/query-db-collection").QueryCollectionUtils<MetaEntity, string | number, MetaEntity, unknown>, never, MetaEntity> & import("@tanstack/db").NonSingleResult;
export type MetaEntityCollection = ReturnType<typeof createMetaEntityCollection>;
export declare function objectTypeCollectionOptions(metadata: MetaEntityCollection): OntologyCollectionOptions;
export declare function valueTypeCollectionOptions(metadata: MetaEntityCollection): OntologyCollectionOptions;
export declare function linkTypeCollectionOptions(metadata: MetaEntityCollection): OntologyCollectionOptions;
export {};
//# sourceMappingURL=entityCollectionOptions.d.ts.map