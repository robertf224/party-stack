export {};
//# sourceMappingURL=convertMetaQueryFunctionType.test.d.ts.map