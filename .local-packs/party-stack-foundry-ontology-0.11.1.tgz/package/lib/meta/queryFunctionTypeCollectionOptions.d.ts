import { QueryClient } from "@tanstack/query-core";
import type { OntologyClient } from "@party-stack/foundry-client";
import type { OntologyCollectionOptions } from "@party-stack/ontology";
export interface QueryFunctionTypeCollectionOpts {
    client: OntologyClient;
    queryClient?: QueryClient;
}
export declare function queryFunctionTypeCollectionOptions(opts: QueryFunctionTypeCollectionOpts): OntologyCollectionOptions;
//# sourceMappingURL=queryFunctionTypeCollectionOptions.d.ts.map