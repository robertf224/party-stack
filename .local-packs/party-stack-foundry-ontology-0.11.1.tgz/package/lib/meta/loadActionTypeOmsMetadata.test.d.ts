export {};
//# sourceMappingURL=loadActionTypeOmsMetadata.test.d.ts.map