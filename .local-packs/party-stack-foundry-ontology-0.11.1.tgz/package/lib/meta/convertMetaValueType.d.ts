import type { MetaValueType } from "@party-stack/ontology";
import type { OntologyValueType } from "@osdk/foundry.ontologies";
export declare function convertFoundryMetaValueType(valueType: OntologyValueType): MetaValueType;
//# sourceMappingURL=convertMetaValueType.d.ts.map