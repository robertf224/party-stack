export {};
//# sourceMappingURL=queryFunctionTypeCollectionOptions.test.d.ts.map