import type { PropertyDef, TypeDef } from "@party-stack/ontology";
import type { ObjectPropertyType, StructFieldType, ValueTypeConstraint, ValueTypeFieldType } from "@osdk/foundry.ontologies";
export declare function convertFoundryValueTypeFieldType(type: ValueTypeFieldType, constraints?: ValueTypeConstraint[]): TypeDef;
export declare function convertFoundryObjectPropertyType(type: ObjectPropertyType): TypeDef;
export declare function convertFoundryStructField(field: StructFieldType): PropertyDef;
//# sourceMappingURL=convertMetaTypeDef.d.ts.map