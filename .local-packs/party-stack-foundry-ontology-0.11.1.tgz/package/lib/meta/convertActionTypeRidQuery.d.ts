import { LoadSubsetOptions } from "@tanstack/db";
export type ActionTypeRidQuery = {
    type: "byRid";
    rids: string[];
} | {
    type: "search";
};
/**
 * Detects exact ActionType.id RID lookups so they can be resolved via
 * `ActionTypesV2.getByRid` instead of the search endpoint (which cannot filter by RID).
 *
 * Only pure `eq` / `inArray` trees over `id` are pushed down. Mixed predicates fall back to search.
 */
export declare function convertActionTypeRidQuery(options?: LoadSubsetOptions): ActionTypeRidQuery;
//# sourceMappingURL=convertActionTypeRidQuery.d.ts.map