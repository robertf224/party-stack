import { LoadSubsetOptions } from "@tanstack/db";
import type { ActionTypeSearchJsonQueryV2, SearchActionTypesOrderByV2 } from "@osdk/foundry.ontologies";
export declare function convertActionTypeLoadSubsetFilter(filter: LoadSubsetOptions["where"]): ActionTypeSearchJsonQueryV2 | undefined;
export declare function convertActionTypeLoadSubsetOrderBy(orderBy: LoadSubsetOptions["orderBy"]): SearchActionTypesOrderByV2 | undefined;
//# sourceMappingURL=convertActionTypeLoadSubsetOptions.d.ts.map