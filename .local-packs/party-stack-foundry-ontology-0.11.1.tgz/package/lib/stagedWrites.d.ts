import type { OntologyIR, OntologyMutator, OntologyMutatorObjects, OntologyMutatorTx } from "@party-stack/ontology";
import type { InitialQueryBuilder } from "@tanstack/db";
/**
 * Structural subset of Foundry's staged-write `WriteableClient`.
 * Generated Foundry clients can be passed directly.
 */
export interface FoundryStagedWriteClient {
    create(objectType: unknown, object: Record<string, unknown>): Promise<unknown>;
    update(object: {
        $apiName: string;
        $primaryKey: string | number;
    }, changes: Record<string, unknown>): Promise<unknown>;
    delete(object: {
        $apiName: string;
        $primaryKey: string | number;
    }): Promise<unknown>;
    query?<T>(build: (query: InitialQueryBuilder, objects: OntologyMutatorObjects) => unknown): Promise<T>;
}
export interface CreateFoundryStagedWriteMutatorTxOptions {
    client: FoundryStagedWriteClient;
    /**
     * Generated OSDK object type tokens, keyed by ontology API name. Required
     * for creates when the client cannot accept an `$apiName` placeholder.
     */
    objectTypes?: Record<string, unknown>;
}
export declare function createFoundryStagedWriteMutatorTx(options: CreateFoundryStagedWriteMutatorTxOptions): OntologyMutatorTx;
/**
 * Run a Party Stack ontology mutator inside Foundry's ambient staged-write
 * transaction. Foundry provides atomic commit/rollback and read-after-write.
 */
export declare function runFoundryOntologyMutator(options: {
    ir: OntologyIR;
    client: FoundryStagedWriteClient;
    mutator: OntologyMutator;
    args: Record<string, unknown>;
    context?: Record<string, unknown>;
    objectTypes?: Record<string, unknown>;
}): Promise<void>;
//# sourceMappingURL=stagedWrites.d.ts.map