import { type PartialAttachmentMetadata, type OntologyBackendAdapter, type OntologyBackendAdapterProvider, type OntologyCollectionOptions, type OntologyIR } from "@party-stack/ontology";
import type { OntologyClient } from "@party-stack/foundry-client";
import type { attachment } from "@party-stack/ontology/values";
export declare function isFoundryNotFoundError(error: unknown): boolean;
export interface FoundryUsersIntegration {
    objectType: string;
    getCollectionOptions(client: OntologyClient): OntologyCollectionOptions;
    getAttachmentContent?(client: OntologyClient, attachment: attachment): Promise<Blob | undefined>;
    getAttachmentMetadata?(client: OntologyClient, attachment: attachment, selection: readonly (keyof PartialAttachmentMetadata)[]): Promise<PartialAttachmentMetadata | undefined>;
}
export declare function createFoundryOntologyBackendAdapter(opts: {
    client: OntologyClient;
    ir: OntologyIR;
    users?: FoundryUsersIntegration;
}): OntologyBackendAdapter;
export type CreateFoundryOntologyBackendOptions<Context extends Record<string, unknown> = Record<string, unknown>> = ({
    client: OntologyClient;
} | {
    createClient: (ir: OntologyIR, context: Context) => OntologyClient | Promise<OntologyClient>;
}) & {
    users?: FoundryUsersIntegration;
};
export declare function createFoundryOntologyBackend<Context extends Record<string, unknown> = Record<string, unknown>>(opts: CreateFoundryOntologyBackendOptions<Context>): OntologyBackendAdapterProvider<Context>;
//# sourceMappingURL=createFoundryOntologyBackendAdapter.d.ts.map