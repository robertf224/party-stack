export {};
//# sourceMappingURL=createFoundryOntologyBackendAdapter.test.d.ts.map