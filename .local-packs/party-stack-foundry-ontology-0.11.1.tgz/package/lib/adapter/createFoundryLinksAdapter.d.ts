import { type OntologyClient } from "@party-stack/foundry-client";
import { type OntologyIR, type OntologyLinksAdapter } from "@party-stack/ontology";
import type { FoundryCodec } from "./foundryCodec.js";
export declare function createFoundryLinksAdapter(opts: {
    client: OntologyClient;
    ir: OntologyIR;
    codec: FoundryCodec;
}): OntologyLinksAdapter;
//# sourceMappingURL=createFoundryLinksAdapter.d.ts.map