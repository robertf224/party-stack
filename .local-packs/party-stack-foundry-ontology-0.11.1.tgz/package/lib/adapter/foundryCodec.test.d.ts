export {};
//# sourceMappingURL=foundryCodec.test.d.ts.map