export {};
//# sourceMappingURL=objectCollectionOptions.test.d.ts.map