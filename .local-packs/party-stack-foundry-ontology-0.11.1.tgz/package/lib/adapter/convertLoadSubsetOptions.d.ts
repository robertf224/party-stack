import { SearchJsonQueryV2, SearchOrderByV2 } from "@osdk/foundry.ontologies";
import { LoadSubsetOptions } from "@tanstack/db";
export declare function isAlwaysFalseFilter(filter: SearchJsonQueryV2 | undefined): boolean;
export declare function convertLoadSubsetFilter(filter: LoadSubsetOptions["where"]): SearchJsonQueryV2 | undefined;
export declare function convertLoadSubsetOrderBy(orderBy: LoadSubsetOptions["orderBy"]): SearchOrderByV2 | undefined;
//# sourceMappingURL=convertLoadSubsetOptions.d.ts.map