import type { MediaItemRid, MediaReference, MediaSetRid, MediaSetViewRid } from "@osdk/foundry.core";
export interface FoundryMediaId {
    mediaSetRid: MediaSetRid;
    mediaSetViewRid: MediaSetViewRid;
    mediaItemRid: MediaItemRid;
}
export declare function encodeFoundryMediaId(value: FoundryMediaId): string;
export declare function decodeFoundryMediaId(value: string): FoundryMediaId | undefined;
export declare function mediaReferenceToFoundryMediaId(value: MediaReference): string;
export declare function foundryMediaIdToReference(id: FoundryMediaId, mimeType: string): MediaReference;
//# sourceMappingURL=foundryMediaId.d.ts.map