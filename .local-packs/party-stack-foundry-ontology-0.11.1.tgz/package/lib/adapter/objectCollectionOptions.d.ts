import { OntologyObjectV2 } from "@osdk/foundry.ontologies";
import { CollectionConfig, InferSchemaOutput, StandardSchema, SyncConfig, UtilsRecord } from "@tanstack/db";
import type { OntologyClient } from "@party-stack/foundry-client";
type WithRequired<T, K extends keyof T> = T & {
    [P in K]-?: T[P];
};
interface OntologyObject extends OntologyObjectV2 {
    __primaryKey: string | number;
}
export interface ObjectCollectionUtils extends UtilsRecord {
    awaitOperationId: (operationId: string, timeout?: number) => Promise<boolean>;
}
export interface ObjectCollectionOpts {
    client: OntologyClient;
    objectType: string;
    primaryKeyProperty: string;
    selectedProperties: string[];
    decodeObject?: (object: Record<string, unknown>) => Record<string, unknown>;
}
export interface ObjectCollectionConfig<TSchema extends StandardSchema<OntologyObject>> extends ObjectCollectionOpts, Omit<CollectionConfig<InferSchemaOutput<TSchema>, string | number, TSchema>, "sync" | "syncMode" | "getKey" | "onInsert" | "onUpdate" | "onDelete"> {
    schema: TSchema;
}
export declare function objectCollectionOptions<TSchema extends StandardSchema<OntologyObject>>(config: ObjectCollectionConfig<TSchema>): WithRequired<CollectionConfig<InferSchemaOutput<TSchema>, string | number, TSchema, ObjectCollectionUtils>, "schema">;
export declare function objectCollectionOptions(config: ObjectCollectionOpts): {
    syncMode: "on-demand";
    sync: SyncConfig<Record<string, unknown>, string | number>;
    utils: ObjectCollectionUtils;
};
export {};
//# sourceMappingURL=objectCollectionOptions.d.ts.map