export {};
//# sourceMappingURL=createFoundryLinksAdapter.test.d.ts.map