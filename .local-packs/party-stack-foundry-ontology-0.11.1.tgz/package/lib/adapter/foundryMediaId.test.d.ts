export {};
//# sourceMappingURL=foundryMediaId.test.d.ts.map