import type { OntologyIR, TypeDef } from "@party-stack/ontology";
import type { MediaReference } from "@osdk/foundry.core";
import type { OntologyObjectV2 } from "@osdk/foundry.ontologies";
type FoundryObjectRecord = Record<string, unknown>;
/** @deprecated Use {@link FoundryCodec} instead. */
export type FoundryObjectDecoder = FoundryCodec;
/** @deprecated Use {@link createFoundryCodec} instead. */
export declare const createFoundryObjectDecoder: typeof createFoundryCodec;
export interface FoundryCodec {
    decodeObject: (objectType: string, object: OntologyObjectV2 | FoundryObjectRecord) => FoundryObjectRecord;
    decodeValue: (type: TypeDef, value: unknown) => unknown;
    encodeValue: (type: TypeDef, value: unknown) => unknown;
}
export declare function createFoundryCodec(ir: OntologyIR, options?: {
    resolveMediaReference?: (id: string) => MediaReference | undefined;
}): FoundryCodec;
export {};
//# sourceMappingURL=foundryCodec.d.ts.map