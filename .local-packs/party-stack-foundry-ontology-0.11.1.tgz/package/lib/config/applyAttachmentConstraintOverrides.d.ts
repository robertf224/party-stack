import type { AttachmentConstraint, OntologyIR } from "@party-stack/ontology";
import type { OntologyAttachmentBindingTarget } from "@party-stack/ontology/utils";
export interface FoundryAttachmentConstraintOverride {
    target: OntologyAttachmentBindingTarget;
    constraint: AttachmentConstraint;
}
export declare function applyAttachmentConstraintOverrides(ontology: OntologyIR, overrides: FoundryAttachmentConstraintOverride[]): OntologyIR;
//# sourceMappingURL=applyAttachmentConstraintOverrides.d.ts.map