import { type Lens, type OntologyPullSource, type OntologyPullConfig } from "@party-stack/ontology";
import { type FoundryAuthenticationClient, type FoundryOAuthConnectionOptions } from "../connection.js";
import { type FoundryAttachmentConstraintOverride } from "./applyAttachmentConstraintOverrides.js";
export type { FoundryAttachmentConstraintOverride } from "./applyAttachmentConstraintOverrides.js";
export interface FoundryOntologyPullConnectionOptions {
    oauth?: FoundryOAuthConnectionOptions;
    token?: string;
    userId?: string;
}
export interface CreateFoundryOntologyPullSourceOptions {
    baseUrl: string;
    ontologyRid: string;
    connection: FoundryOntologyPullConnectionOptions;
    attachmentConstraints?: FoundryAttachmentConstraintOverride[];
    users?: {
        objectType: string;
        lens: Lens;
    };
}
export declare function createFoundryOntologyPullSource(options: CreateFoundryOntologyPullSourceOptions): OntologyPullSource<FoundryAuthenticationClient>;
export type FoundryOntologyPullConfig = OntologyPullConfig<FoundryAuthenticationClient>;
//# sourceMappingURL=index.d.ts.map