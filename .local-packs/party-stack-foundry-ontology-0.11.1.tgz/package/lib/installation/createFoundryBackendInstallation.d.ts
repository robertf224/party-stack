import { type LiveOntologyWrites, type OntologyBackendInstallation, type OntologyRoute } from "@party-stack/ontology";
import type { BackendConnectionAdapterProvider } from "@party-stack/connections";
import type { OntologyIR } from "@party-stack/ontology";
import type { RuntimeAdapterProvider } from "@party-stack/runtime";
import { type FoundryUsersIntegration } from "../adapter/createFoundryOntologyBackendAdapter.js";
import { type CreateFoundryConnectionAdapterOptions, type FoundryAuthenticationClient } from "../connection.js";
export type FoundryConnectionOptions = Omit<CreateFoundryConnectionAdapterOptions, "baseUrl">;
export type FoundryOntologyRoute = (baseUrl: string) => OntologyRoute;
export interface CreateFoundryBackendInstallationOptions<AuthenticationClient extends object = FoundryAuthenticationClient> {
    installationId?: string;
    baseUrl: string;
    runtime: RuntimeAdapterProvider;
    connections: FoundryConnectionOptions | BackendConnectionAdapterProvider<AuthenticationClient>;
    routes: readonly FoundryOntologyRoute[];
    createContext?: (userId: string, ontologyId: string) => Record<string, unknown>;
}
export declare function createFoundryOntologyRoute(options: {
    ontologyId: string;
    ir?: OntologyIR;
    users?: FoundryUsersIntegration | ((userId: string) => FoundryUsersIntegration);
    persistObjects?: boolean;
    writes?: LiveOntologyWrites;
}): FoundryOntologyRoute;
export declare function createFoundryBackendInstallation<AuthenticationClient extends object = FoundryAuthenticationClient>(options: CreateFoundryBackendInstallationOptions<AuthenticationClient>): Promise<OntologyBackendInstallation<AuthenticationClient>>;
//# sourceMappingURL=createFoundryBackendInstallation.d.ts.map