import { type Lens } from "@party-stack/ontology";
import type { Client } from "@party-stack/foundry-client";
export interface UserCollectionOpts {
    client: Client;
    lens: Lens;
}
export declare function userCollectionOptions({ client, lens }: UserCollectionOpts): import("@tanstack/db").CollectionConfig<Record<string, unknown>, string | number, never, import("@tanstack/query-db-collection").QueryCollectionUtils<Record<string, unknown>, string | number, Record<string, unknown>, unknown>> & {
    schema?: never;
    utils: import("@tanstack/query-db-collection").QueryCollectionUtils<Record<string, unknown>, string | number, Record<string, unknown>, unknown>;
};
//# sourceMappingURL=userCollectionOptions.d.ts.map