import { type FoundryOntologyRoute } from "../installation/createFoundryBackendInstallation.js";
export declare const foundryAdminOntology: {
    types: never[];
    objectTypes: {
        name: string;
        displayName: string;
        pluralDisplayName: string;
        primaryKey: string;
        title?: string | undefined;
        properties: {
            name: string;
            displayName: string;
            type: {
                kind: "string";
                value: {
                    constraint?: {
                        kind: "regex";
                        value: {
                            regex: string;
                        };
                    } | {
                        kind: "enum";
                        value: {
                            options: {
                                value: string;
                                label?: string | undefined;
                            }[];
                        };
                    } | undefined;
                };
            } | {
                kind: "boolean";
                value: {};
            } | {
                kind: "map";
                value: {
                    keyType: {
                        kind: "string";
                        value: {
                            constraint?: {
                                kind: "regex";
                                value: {
                                    regex: string;
                                };
                            } | {
                                kind: "enum";
                                value: {
                                    options: {
                                        value: string;
                                        label?: string | undefined;
                                    }[];
                                };
                            } | undefined;
                        };
                    } | {
                        kind: "boolean";
                        value: {};
                    } | /*elided*/ any | {
                        kind: "result";
                        value: {
                            okType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | /*elided*/ any | /*elided*/ any | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | {
                                kind: "list";
                                value: {
                                    elementType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | {
                                kind: "optional";
                                value: {
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                            errType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | /*elided*/ any | /*elided*/ any | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | {
                                kind: "list";
                                value: {
                                    elementType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | {
                                kind: "optional";
                                value: {
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | {
                        kind: "ref";
                        value: {
                            name: string;
                        };
                    } | {
                        kind: "timestamp";
                        value: {};
                    } | {
                        kind: "attachment";
                        value: {
                            constraint?: {
                                size?: {
                                    min?: import("@party-stack/ontology/values").double | undefined;
                                    max?: import("@party-stack/ontology/values").double | undefined;
                                } | undefined;
                                content?: {
                                    kind: "image";
                                    value: {
                                        mediaTypes?: import("@party-stack/ontology").ImageMediaType[] | undefined;
                                        dimensions?: {
                                            width?: /*elided*/ any | undefined;
                                            height?: /*elided*/ any | undefined;
                                        } | undefined;
                                    };
                                } | undefined;
                            } | undefined;
                            meta?: {
                                [x: string]: unknown;
                            } | undefined;
                        };
                    } | {
                        kind: "union";
                        value: {
                            variants: {
                                name: string;
                                type: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | /*elided*/ any | {
                                    kind: "result";
                                    value: {
                                        okType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        errType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | /*elided*/ any | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "struct";
                                    value: {
                                        fields: {
                                            name: string;
                                            displayName: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            description?: string | undefined;
                                            deprecated?: /*elided*/ any | undefined;
                                        }[];
                                    };
                                } | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                            }[];
                        };
                    } | {
                        kind: "integer";
                        value: {};
                    } | {
                        kind: "float";
                        value: {};
                    } | {
                        kind: "double";
                        value: {};
                    } | {
                        kind: "date";
                        value: {};
                    } | {
                        kind: "geopoint";
                        value: {};
                    } | {
                        kind: "list";
                        value: {
                            elementType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "result";
                                value: {
                                    okType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    errType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | {
                                kind: "optional";
                                value: {
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "result";
                                        value: {
                                            okType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            errType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | {
                        kind: "struct";
                        value: {
                            fields: {
                                name: string;
                                displayName: string;
                                type: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | /*elided*/ any | {
                                    kind: "result";
                                    value: {
                                        okType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        errType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "union";
                                    value: {
                                        variants: {
                                            name: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        }[];
                                    };
                                } | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                                description?: string | undefined;
                                deprecated?: {
                                    message: string;
                                } | undefined;
                            }[];
                        };
                    } | {
                        kind: "optional";
                        value: {
                            type: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "result";
                                value: {
                                    okType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    errType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | {
                                kind: "list";
                                value: {
                                    elementType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "result";
                                        value: {
                                            okType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            errType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | /*elided*/ any | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | {
                        kind: "objectReference";
                        value: {
                            objectType: string;
                        };
                    } | {
                        kind: "unknown";
                        value: {};
                    };
                    valueType: {
                        kind: "string";
                        value: {
                            constraint?: {
                                kind: "regex";
                                value: {
                                    regex: string;
                                };
                            } | {
                                kind: "enum";
                                value: {
                                    options: {
                                        value: string;
                                        label?: string | undefined;
                                    }[];
                                };
                            } | undefined;
                        };
                    } | {
                        kind: "boolean";
                        value: {};
                    } | /*elided*/ any | {
                        kind: "result";
                        value: {
                            okType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | /*elided*/ any | /*elided*/ any | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | {
                                kind: "list";
                                value: {
                                    elementType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | {
                                kind: "optional";
                                value: {
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                            errType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | /*elided*/ any | /*elided*/ any | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | {
                                kind: "list";
                                value: {
                                    elementType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | {
                                kind: "optional";
                                value: {
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | {
                        kind: "ref";
                        value: {
                            name: string;
                        };
                    } | {
                        kind: "timestamp";
                        value: {};
                    } | {
                        kind: "attachment";
                        value: {
                            constraint?: {
                                size?: {
                                    min?: import("@party-stack/ontology/values").double | undefined;
                                    max?: import("@party-stack/ontology/values").double | undefined;
                                } | undefined;
                                content?: {
                                    kind: "image";
                                    value: {
                                        mediaTypes?: import("@party-stack/ontology").ImageMediaType[] | undefined;
                                        dimensions?: {
                                            width?: /*elided*/ any | undefined;
                                            height?: /*elided*/ any | undefined;
                                        } | undefined;
                                    };
                                } | undefined;
                            } | undefined;
                            meta?: {
                                [x: string]: unknown;
                            } | undefined;
                        };
                    } | {
                        kind: "union";
                        value: {
                            variants: {
                                name: string;
                                type: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | /*elided*/ any | {
                                    kind: "result";
                                    value: {
                                        okType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        errType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | /*elided*/ any | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "struct";
                                    value: {
                                        fields: {
                                            name: string;
                                            displayName: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            description?: string | undefined;
                                            deprecated?: /*elided*/ any | undefined;
                                        }[];
                                    };
                                } | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                            }[];
                        };
                    } | {
                        kind: "integer";
                        value: {};
                    } | {
                        kind: "float";
                        value: {};
                    } | {
                        kind: "double";
                        value: {};
                    } | {
                        kind: "date";
                        value: {};
                    } | {
                        kind: "geopoint";
                        value: {};
                    } | {
                        kind: "list";
                        value: {
                            elementType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "result";
                                value: {
                                    okType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    errType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | {
                                kind: "optional";
                                value: {
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "result";
                                        value: {
                                            okType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            errType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | {
                        kind: "struct";
                        value: {
                            fields: {
                                name: string;
                                displayName: string;
                                type: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | /*elided*/ any | {
                                    kind: "result";
                                    value: {
                                        okType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        errType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "union";
                                    value: {
                                        variants: {
                                            name: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        }[];
                                    };
                                } | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                                description?: string | undefined;
                                deprecated?: {
                                    message: string;
                                } | undefined;
                            }[];
                        };
                    } | {
                        kind: "optional";
                        value: {
                            type: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "result";
                                value: {
                                    okType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    errType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | {
                                kind: "list";
                                value: {
                                    elementType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "result";
                                        value: {
                                            okType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            errType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | /*elided*/ any | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | {
                        kind: "objectReference";
                        value: {
                            objectType: string;
                        };
                    } | {
                        kind: "unknown";
                        value: {};
                    };
                };
            } | {
                kind: "result";
                value: {
                    okType: {
                        kind: "string";
                        value: {
                            constraint?: {
                                kind: "regex";
                                value: {
                                    regex: string;
                                };
                            } | {
                                kind: "enum";
                                value: {
                                    options: {
                                        value: string;
                                        label?: string | undefined;
                                    }[];
                                };
                            } | undefined;
                        };
                    } | {
                        kind: "boolean";
                        value: {};
                    } | {
                        kind: "map";
                        value: {
                            keyType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | /*elided*/ any | /*elided*/ any | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | {
                                kind: "list";
                                value: {
                                    elementType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | {
                                kind: "optional";
                                value: {
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                            valueType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | /*elided*/ any | /*elided*/ any | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | {
                                kind: "list";
                                value: {
                                    elementType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | {
                                kind: "optional";
                                value: {
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | /*elided*/ any | {
                        kind: "ref";
                        value: {
                            name: string;
                        };
                    } | {
                        kind: "timestamp";
                        value: {};
                    } | {
                        kind: "attachment";
                        value: {
                            constraint?: {
                                size?: {
                                    min?: import("@party-stack/ontology/values").double | undefined;
                                    max?: import("@party-stack/ontology/values").double | undefined;
                                } | undefined;
                                content?: {
                                    kind: "image";
                                    value: {
                                        mediaTypes?: import("@party-stack/ontology").ImageMediaType[] | undefined;
                                        dimensions?: {
                                            width?: /*elided*/ any | undefined;
                                            height?: /*elided*/ any | undefined;
                                        } | undefined;
                                    };
                                } | undefined;
                            } | undefined;
                            meta?: {
                                [x: string]: unknown;
                            } | undefined;
                        };
                    } | {
                        kind: "union";
                        value: {
                            variants: {
                                name: string;
                                type: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | {
                                    kind: "map";
                                    value: {
                                        keyType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        valueType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | /*elided*/ any | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "struct";
                                    value: {
                                        fields: {
                                            name: string;
                                            displayName: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            description?: string | undefined;
                                            deprecated?: /*elided*/ any | undefined;
                                        }[];
                                    };
                                } | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                            }[];
                        };
                    } | {
                        kind: "integer";
                        value: {};
                    } | {
                        kind: "float";
                        value: {};
                    } | {
                        kind: "double";
                        value: {};
                    } | {
                        kind: "date";
                        value: {};
                    } | {
                        kind: "geopoint";
                        value: {};
                    } | {
                        kind: "list";
                        value: {
                            elementType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | {
                                kind: "map";
                                value: {
                                    keyType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    valueType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | /*elided*/ any | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | {
                                kind: "optional";
                                value: {
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | {
                                        kind: "map";
                                        value: {
                                            keyType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            valueType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | {
                        kind: "struct";
                        value: {
                            fields: {
                                name: string;
                                displayName: string;
                                type: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | {
                                    kind: "map";
                                    value: {
                                        keyType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        valueType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "union";
                                    value: {
                                        variants: {
                                            name: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        }[];
                                    };
                                } | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                                description?: string | undefined;
                                deprecated?: {
                                    message: string;
                                } | undefined;
                            }[];
                        };
                    } | {
                        kind: "optional";
                        value: {
                            type: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | {
                                kind: "map";
                                value: {
                                    keyType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    valueType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | /*elided*/ any | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | {
                                kind: "list";
                                value: {
                                    elementType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | {
                                        kind: "map";
                                        value: {
                                            keyType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            valueType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | /*elided*/ any | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | {
                        kind: "objectReference";
                        value: {
                            objectType: string;
                        };
                    } | {
                        kind: "unknown";
                        value: {};
                    };
                    errType: {
                        kind: "string";
                        value: {
                            constraint?: {
                                kind: "regex";
                                value: {
                                    regex: string;
                                };
                            } | {
                                kind: "enum";
                                value: {
                                    options: {
                                        value: string;
                                        label?: string | undefined;
                                    }[];
                                };
                            } | undefined;
                        };
                    } | {
                        kind: "boolean";
                        value: {};
                    } | {
                        kind: "map";
                        value: {
                            keyType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | /*elided*/ any | /*elided*/ any | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | {
                                kind: "list";
                                value: {
                                    elementType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | {
                                kind: "optional";
                                value: {
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                            valueType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | /*elided*/ any | /*elided*/ any | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | {
                                kind: "list";
                                value: {
                                    elementType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | {
                                kind: "optional";
                                value: {
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | /*elided*/ any | {
                        kind: "ref";
                        value: {
                            name: string;
                        };
                    } | {
                        kind: "timestamp";
                        value: {};
                    } | {
                        kind: "attachment";
                        value: {
                            constraint?: {
                                size?: {
                                    min?: import("@party-stack/ontology/values").double | undefined;
                                    max?: import("@party-stack/ontology/values").double | undefined;
                                } | undefined;
                                content?: {
                                    kind: "image";
                                    value: {
                                        mediaTypes?: import("@party-stack/ontology").ImageMediaType[] | undefined;
                                        dimensions?: {
                                            width?: /*elided*/ any | undefined;
                                            height?: /*elided*/ any | undefined;
                                        } | undefined;
                                    };
                                } | undefined;
                            } | undefined;
                            meta?: {
                                [x: string]: unknown;
                            } | undefined;
                        };
                    } | {
                        kind: "union";
                        value: {
                            variants: {
                                name: string;
                                type: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | {
                                    kind: "map";
                                    value: {
                                        keyType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        valueType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | /*elided*/ any | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "struct";
                                    value: {
                                        fields: {
                                            name: string;
                                            displayName: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            description?: string | undefined;
                                            deprecated?: /*elided*/ any | undefined;
                                        }[];
                                    };
                                } | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                            }[];
                        };
                    } | {
                        kind: "integer";
                        value: {};
                    } | {
                        kind: "float";
                        value: {};
                    } | {
                        kind: "double";
                        value: {};
                    } | {
                        kind: "date";
                        value: {};
                    } | {
                        kind: "geopoint";
                        value: {};
                    } | {
                        kind: "list";
                        value: {
                            elementType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | {
                                kind: "map";
                                value: {
                                    keyType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    valueType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | /*elided*/ any | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | {
                                kind: "optional";
                                value: {
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | {
                                        kind: "map";
                                        value: {
                                            keyType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            valueType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | {
                        kind: "struct";
                        value: {
                            fields: {
                                name: string;
                                displayName: string;
                                type: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | {
                                    kind: "map";
                                    value: {
                                        keyType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        valueType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "union";
                                    value: {
                                        variants: {
                                            name: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        }[];
                                    };
                                } | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                                description?: string | undefined;
                                deprecated?: {
                                    message: string;
                                } | undefined;
                            }[];
                        };
                    } | {
                        kind: "optional";
                        value: {
                            type: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | {
                                kind: "map";
                                value: {
                                    keyType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    valueType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | /*elided*/ any | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | {
                                kind: "list";
                                value: {
                                    elementType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | {
                                        kind: "map";
                                        value: {
                                            keyType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            valueType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | /*elided*/ any | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | {
                        kind: "objectReference";
                        value: {
                            objectType: string;
                        };
                    } | {
                        kind: "unknown";
                        value: {};
                    };
                };
            } | {
                kind: "ref";
                value: {
                    name: string;
                };
            } | {
                kind: "timestamp";
                value: {};
            } | {
                kind: "attachment";
                value: {
                    constraint?: {
                        size?: {
                            min?: import("@party-stack/ontology/values").double | undefined;
                            max?: import("@party-stack/ontology/values").double | undefined;
                        } | undefined;
                        content?: {
                            kind: "image";
                            value: {
                                mediaTypes?: import("@party-stack/ontology").ImageMediaType[] | undefined;
                                dimensions?: {
                                    width?: {
                                        min?: import("@party-stack/ontology/values").integer | undefined;
                                        max?: import("@party-stack/ontology/values").integer | undefined;
                                    } | undefined;
                                    height?: {
                                        min?: import("@party-stack/ontology/values").integer | undefined;
                                        max?: import("@party-stack/ontology/values").integer | undefined;
                                    } | undefined;
                                } | undefined;
                            };
                        } | undefined;
                    } | undefined;
                    meta?: {
                        [x: string]: unknown;
                    } | undefined;
                };
            } | {
                kind: "union";
                value: {
                    variants: {
                        name: string;
                        type: {
                            kind: "string";
                            value: {
                                constraint?: {
                                    kind: "regex";
                                    value: {
                                        regex: string;
                                    };
                                } | {
                                    kind: "enum";
                                    value: {
                                        options: {
                                            value: string;
                                            label?: string | undefined;
                                        }[];
                                    };
                                } | undefined;
                            };
                        } | {
                            kind: "boolean";
                            value: {};
                        } | {
                            kind: "map";
                            value: {
                                keyType: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | /*elided*/ any | {
                                    kind: "result";
                                    value: {
                                        okType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        errType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | /*elided*/ any | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "struct";
                                    value: {
                                        fields: {
                                            name: string;
                                            displayName: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            description?: string | undefined;
                                            deprecated?: /*elided*/ any | undefined;
                                        }[];
                                    };
                                } | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                                valueType: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | /*elided*/ any | {
                                    kind: "result";
                                    value: {
                                        okType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        errType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | /*elided*/ any | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "struct";
                                    value: {
                                        fields: {
                                            name: string;
                                            displayName: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            description?: string | undefined;
                                            deprecated?: /*elided*/ any | undefined;
                                        }[];
                                    };
                                } | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                            };
                        } | {
                            kind: "result";
                            value: {
                                okType: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | {
                                    kind: "map";
                                    value: {
                                        keyType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        valueType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | /*elided*/ any | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "struct";
                                    value: {
                                        fields: {
                                            name: string;
                                            displayName: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            description?: string | undefined;
                                            deprecated?: /*elided*/ any | undefined;
                                        }[];
                                    };
                                } | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                                errType: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | {
                                    kind: "map";
                                    value: {
                                        keyType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        valueType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | /*elided*/ any | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "struct";
                                    value: {
                                        fields: {
                                            name: string;
                                            displayName: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            description?: string | undefined;
                                            deprecated?: /*elided*/ any | undefined;
                                        }[];
                                    };
                                } | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                            };
                        } | {
                            kind: "ref";
                            value: {
                                name: string;
                            };
                        } | {
                            kind: "timestamp";
                            value: {};
                        } | {
                            kind: "attachment";
                            value: {
                                constraint?: {
                                    size?: {
                                        min?: import("@party-stack/ontology/values").double | undefined;
                                        max?: import("@party-stack/ontology/values").double | undefined;
                                    } | undefined;
                                    content?: {
                                        kind: "image";
                                        value: {
                                            mediaTypes?: import("@party-stack/ontology").ImageMediaType[] | undefined;
                                            dimensions?: /*elided*/ any | undefined;
                                        };
                                    } | undefined;
                                } | undefined;
                                meta?: {
                                    [x: string]: unknown;
                                } | undefined;
                            };
                        } | /*elided*/ any | {
                            kind: "integer";
                            value: {};
                        } | {
                            kind: "float";
                            value: {};
                        } | {
                            kind: "double";
                            value: {};
                        } | {
                            kind: "date";
                            value: {};
                        } | {
                            kind: "geopoint";
                            value: {};
                        } | {
                            kind: "list";
                            value: {
                                elementType: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | {
                                    kind: "map";
                                    value: {
                                        keyType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        valueType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "result";
                                    value: {
                                        okType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        errType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | /*elided*/ any | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | /*elided*/ any | {
                                    kind: "struct";
                                    value: {
                                        fields: {
                                            name: string;
                                            displayName: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            description?: string | undefined;
                                            deprecated?: /*elided*/ any | undefined;
                                        }[];
                                    };
                                } | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                            };
                        } | {
                            kind: "struct";
                            value: {
                                fields: {
                                    name: string;
                                    displayName: string;
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | {
                                        kind: "map";
                                        value: {
                                            keyType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            valueType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "result";
                                        value: {
                                            okType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            errType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | /*elided*/ any | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | /*elided*/ any | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    description?: string | undefined;
                                    deprecated?: {
                                        message: string;
                                    } | undefined;
                                }[];
                            };
                        } | {
                            kind: "optional";
                            value: {
                                type: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | {
                                    kind: "map";
                                    value: {
                                        keyType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        valueType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "result";
                                    value: {
                                        okType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        errType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | /*elided*/ any | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "struct";
                                    value: {
                                        fields: {
                                            name: string;
                                            displayName: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            description?: string | undefined;
                                            deprecated?: /*elided*/ any | undefined;
                                        }[];
                                    };
                                } | /*elided*/ any | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                            };
                        } | {
                            kind: "objectReference";
                            value: {
                                objectType: string;
                            };
                        } | {
                            kind: "unknown";
                            value: {};
                        };
                    }[];
                };
            } | {
                kind: "integer";
                value: {};
            } | {
                kind: "float";
                value: {};
            } | {
                kind: "double";
                value: {};
            } | {
                kind: "date";
                value: {};
            } | {
                kind: "geopoint";
                value: {};
            } | {
                kind: "list";
                value: {
                    elementType: {
                        kind: "string";
                        value: {
                            constraint?: {
                                kind: "regex";
                                value: {
                                    regex: string;
                                };
                            } | {
                                kind: "enum";
                                value: {
                                    options: {
                                        value: string;
                                        label?: string | undefined;
                                    }[];
                                };
                            } | undefined;
                        };
                    } | {
                        kind: "boolean";
                        value: {};
                    } | {
                        kind: "map";
                        value: {
                            keyType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "result";
                                value: {
                                    okType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    errType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | {
                                kind: "optional";
                                value: {
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "result";
                                        value: {
                                            okType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            errType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                            valueType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "result";
                                value: {
                                    okType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    errType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | {
                                kind: "optional";
                                value: {
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "result";
                                        value: {
                                            okType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            errType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | {
                        kind: "result";
                        value: {
                            okType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | {
                                kind: "map";
                                value: {
                                    keyType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    valueType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | /*elided*/ any | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | {
                                kind: "optional";
                                value: {
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | {
                                        kind: "map";
                                        value: {
                                            keyType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            valueType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                            errType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | {
                                kind: "map";
                                value: {
                                    keyType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    valueType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | /*elided*/ any | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | {
                                kind: "optional";
                                value: {
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | {
                                        kind: "map";
                                        value: {
                                            keyType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            valueType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | {
                        kind: "ref";
                        value: {
                            name: string;
                        };
                    } | {
                        kind: "timestamp";
                        value: {};
                    } | {
                        kind: "attachment";
                        value: {
                            constraint?: {
                                size?: {
                                    min?: import("@party-stack/ontology/values").double | undefined;
                                    max?: import("@party-stack/ontology/values").double | undefined;
                                } | undefined;
                                content?: {
                                    kind: "image";
                                    value: {
                                        mediaTypes?: import("@party-stack/ontology").ImageMediaType[] | undefined;
                                        dimensions?: {
                                            width?: /*elided*/ any | undefined;
                                            height?: /*elided*/ any | undefined;
                                        } | undefined;
                                    };
                                } | undefined;
                            } | undefined;
                            meta?: {
                                [x: string]: unknown;
                            } | undefined;
                        };
                    } | {
                        kind: "union";
                        value: {
                            variants: {
                                name: string;
                                type: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | {
                                    kind: "map";
                                    value: {
                                        keyType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        valueType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "result";
                                    value: {
                                        okType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        errType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | /*elided*/ any | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | /*elided*/ any | {
                                    kind: "struct";
                                    value: {
                                        fields: {
                                            name: string;
                                            displayName: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            description?: string | undefined;
                                            deprecated?: /*elided*/ any | undefined;
                                        }[];
                                    };
                                } | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                            }[];
                        };
                    } | {
                        kind: "integer";
                        value: {};
                    } | {
                        kind: "float";
                        value: {};
                    } | {
                        kind: "double";
                        value: {};
                    } | {
                        kind: "date";
                        value: {};
                    } | {
                        kind: "geopoint";
                        value: {};
                    } | /*elided*/ any | {
                        kind: "struct";
                        value: {
                            fields: {
                                name: string;
                                displayName: string;
                                type: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | {
                                    kind: "map";
                                    value: {
                                        keyType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        valueType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "result";
                                    value: {
                                        okType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        errType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "union";
                                    value: {
                                        variants: {
                                            name: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        }[];
                                    };
                                } | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | /*elided*/ any | /*elided*/ any | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                                description?: string | undefined;
                                deprecated?: {
                                    message: string;
                                } | undefined;
                            }[];
                        };
                    } | {
                        kind: "optional";
                        value: {
                            type: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | {
                                kind: "map";
                                value: {
                                    keyType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "result";
                                        value: {
                                            okType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            errType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    valueType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "result";
                                        value: {
                                            okType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            errType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "result";
                                value: {
                                    okType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | {
                                        kind: "map";
                                        value: {
                                            keyType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            valueType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    errType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | {
                                        kind: "map";
                                        value: {
                                            keyType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            valueType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | /*elided*/ any | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | {
                        kind: "objectReference";
                        value: {
                            objectType: string;
                        };
                    } | {
                        kind: "unknown";
                        value: {};
                    };
                };
            } | {
                kind: "struct";
                value: {
                    fields: {
                        name: string;
                        displayName: string;
                        type: {
                            kind: "string";
                            value: {
                                constraint?: {
                                    kind: "regex";
                                    value: {
                                        regex: string;
                                    };
                                } | {
                                    kind: "enum";
                                    value: {
                                        options: {
                                            value: string;
                                            label?: string | undefined;
                                        }[];
                                    };
                                } | undefined;
                            };
                        } | {
                            kind: "boolean";
                            value: {};
                        } | {
                            kind: "map";
                            value: {
                                keyType: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | /*elided*/ any | {
                                    kind: "result";
                                    value: {
                                        okType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        errType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "union";
                                    value: {
                                        variants: {
                                            name: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        }[];
                                    };
                                } | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                                valueType: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | /*elided*/ any | {
                                    kind: "result";
                                    value: {
                                        okType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        errType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "union";
                                    value: {
                                        variants: {
                                            name: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        }[];
                                    };
                                } | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                            };
                        } | {
                            kind: "result";
                            value: {
                                okType: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | {
                                    kind: "map";
                                    value: {
                                        keyType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        valueType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "union";
                                    value: {
                                        variants: {
                                            name: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        }[];
                                    };
                                } | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                                errType: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | {
                                    kind: "map";
                                    value: {
                                        keyType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        valueType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "union";
                                    value: {
                                        variants: {
                                            name: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        }[];
                                    };
                                } | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                            };
                        } | {
                            kind: "ref";
                            value: {
                                name: string;
                            };
                        } | {
                            kind: "timestamp";
                            value: {};
                        } | {
                            kind: "attachment";
                            value: {
                                constraint?: {
                                    size?: {
                                        min?: import("@party-stack/ontology/values").double | undefined;
                                        max?: import("@party-stack/ontology/values").double | undefined;
                                    } | undefined;
                                    content?: {
                                        kind: "image";
                                        value: {
                                            mediaTypes?: import("@party-stack/ontology").ImageMediaType[] | undefined;
                                            dimensions?: /*elided*/ any | undefined;
                                        };
                                    } | undefined;
                                } | undefined;
                                meta?: {
                                    [x: string]: unknown;
                                } | undefined;
                            };
                        } | {
                            kind: "union";
                            value: {
                                variants: {
                                    name: string;
                                    type: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | {
                                        kind: "map";
                                        value: {
                                            keyType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            valueType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "result";
                                        value: {
                                            okType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            errType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | /*elided*/ any | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | /*elided*/ any | {
                                        kind: "optional";
                                        value: {
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                }[];
                            };
                        } | {
                            kind: "integer";
                            value: {};
                        } | {
                            kind: "float";
                            value: {};
                        } | {
                            kind: "double";
                            value: {};
                        } | {
                            kind: "date";
                            value: {};
                        } | {
                            kind: "geopoint";
                            value: {};
                        } | {
                            kind: "list";
                            value: {
                                elementType: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | {
                                    kind: "map";
                                    value: {
                                        keyType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        valueType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "result";
                                    value: {
                                        okType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        errType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "optional";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "union";
                                    value: {
                                        variants: {
                                            name: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        }[];
                                    };
                                } | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | /*elided*/ any | /*elided*/ any | {
                                    kind: "optional";
                                    value: {
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                            };
                        } | /*elided*/ any | {
                            kind: "optional";
                            value: {
                                type: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | {
                                    kind: "map";
                                    value: {
                                        keyType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        valueType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "result";
                                    value: {
                                        okType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        errType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "union";
                                    value: {
                                        variants: {
                                            name: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        }[];
                                    };
                                } | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | /*elided*/ any | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                            };
                        } | {
                            kind: "objectReference";
                            value: {
                                objectType: string;
                            };
                        } | {
                            kind: "unknown";
                            value: {};
                        };
                        description?: string | undefined;
                        deprecated?: {
                            message: string;
                        } | undefined;
                    }[];
                };
            } | {
                kind: "optional";
                value: {
                    type: {
                        kind: "string";
                        value: {
                            constraint?: {
                                kind: "regex";
                                value: {
                                    regex: string;
                                };
                            } | {
                                kind: "enum";
                                value: {
                                    options: {
                                        value: string;
                                        label?: string | undefined;
                                    }[];
                                };
                            } | undefined;
                        };
                    } | {
                        kind: "boolean";
                        value: {};
                    } | {
                        kind: "map";
                        value: {
                            keyType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "result";
                                value: {
                                    okType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    errType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | {
                                kind: "list";
                                value: {
                                    elementType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "result";
                                        value: {
                                            okType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            errType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | /*elided*/ any | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                            valueType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "result";
                                value: {
                                    okType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    errType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | {
                                kind: "list";
                                value: {
                                    elementType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "result";
                                        value: {
                                            okType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            errType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | /*elided*/ any | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | {
                        kind: "result";
                        value: {
                            okType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | {
                                kind: "map";
                                value: {
                                    keyType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    valueType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | /*elided*/ any | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | {
                                kind: "list";
                                value: {
                                    elementType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | {
                                        kind: "map";
                                        value: {
                                            keyType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            valueType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | /*elided*/ any | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                            errType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | {
                                kind: "map";
                                value: {
                                    keyType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    valueType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | {
                                        kind: "list";
                                        value: {
                                            elementType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | /*elided*/ any | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | {
                                kind: "list";
                                value: {
                                    elementType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | {
                                        kind: "map";
                                        value: {
                                            keyType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            valueType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | /*elided*/ any | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | {
                        kind: "ref";
                        value: {
                            name: string;
                        };
                    } | {
                        kind: "timestamp";
                        value: {};
                    } | {
                        kind: "attachment";
                        value: {
                            constraint?: {
                                size?: {
                                    min?: import("@party-stack/ontology/values").double | undefined;
                                    max?: import("@party-stack/ontology/values").double | undefined;
                                } | undefined;
                                content?: {
                                    kind: "image";
                                    value: {
                                        mediaTypes?: import("@party-stack/ontology").ImageMediaType[] | undefined;
                                        dimensions?: {
                                            width?: /*elided*/ any | undefined;
                                            height?: /*elided*/ any | undefined;
                                        } | undefined;
                                    };
                                } | undefined;
                            } | undefined;
                            meta?: {
                                [x: string]: unknown;
                            } | undefined;
                        };
                    } | {
                        kind: "union";
                        value: {
                            variants: {
                                name: string;
                                type: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | {
                                    kind: "map";
                                    value: {
                                        keyType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        valueType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "result";
                                    value: {
                                        okType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        errType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | /*elided*/ any | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "struct";
                                    value: {
                                        fields: {
                                            name: string;
                                            displayName: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            description?: string | undefined;
                                            deprecated?: /*elided*/ any | undefined;
                                        }[];
                                    };
                                } | /*elided*/ any | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                            }[];
                        };
                    } | {
                        kind: "integer";
                        value: {};
                    } | {
                        kind: "float";
                        value: {};
                    } | {
                        kind: "double";
                        value: {};
                    } | {
                        kind: "date";
                        value: {};
                    } | {
                        kind: "geopoint";
                        value: {};
                    } | {
                        kind: "list";
                        value: {
                            elementType: {
                                kind: "string";
                                value: {
                                    constraint?: {
                                        kind: "regex";
                                        value: {
                                            regex: string;
                                        };
                                    } | {
                                        kind: "enum";
                                        value: {
                                            options: /*elided*/ any[];
                                        };
                                    } | undefined;
                                };
                            } | {
                                kind: "boolean";
                                value: {};
                            } | {
                                kind: "map";
                                value: {
                                    keyType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "result";
                                        value: {
                                            okType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            errType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    valueType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "result";
                                        value: {
                                            okType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            errType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "result";
                                value: {
                                    okType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | {
                                        kind: "map";
                                        value: {
                                            keyType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            valueType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                    errType: {
                                        kind: "string";
                                        value: {
                                            constraint?: /*elided*/ any | /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "boolean";
                                        value: {};
                                    } | {
                                        kind: "map";
                                        value: {
                                            keyType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                            valueType: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        };
                                    } | /*elided*/ any | {
                                        kind: "ref";
                                        value: {
                                            name: string;
                                        };
                                    } | {
                                        kind: "timestamp";
                                        value: {};
                                    } | {
                                        kind: "attachment";
                                        value: {
                                            constraint?: /*elided*/ any | undefined;
                                            meta?: /*elided*/ any | undefined;
                                        };
                                    } | {
                                        kind: "union";
                                        value: {
                                            variants: /*elided*/ any[];
                                        };
                                    } | {
                                        kind: "integer";
                                        value: {};
                                    } | {
                                        kind: "float";
                                        value: {};
                                    } | {
                                        kind: "double";
                                        value: {};
                                    } | {
                                        kind: "date";
                                        value: {};
                                    } | {
                                        kind: "geopoint";
                                        value: {};
                                    } | /*elided*/ any | {
                                        kind: "struct";
                                        value: {
                                            fields: /*elided*/ any[];
                                        };
                                    } | /*elided*/ any | {
                                        kind: "objectReference";
                                        value: {
                                            objectType: string;
                                        };
                                    } | {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            } | {
                                kind: "ref";
                                value: {
                                    name: string;
                                };
                            } | {
                                kind: "timestamp";
                                value: {};
                            } | {
                                kind: "attachment";
                                value: {
                                    constraint?: {
                                        size?: {
                                            min?: import("@party-stack/ontology/values").double | undefined;
                                            max?: import("@party-stack/ontology/values").double | undefined;
                                        } | undefined;
                                        content?: {
                                            kind: "image";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    } | undefined;
                                    meta?: {
                                        [x: string]: unknown;
                                    } | undefined;
                                };
                            } | {
                                kind: "union";
                                value: {
                                    variants: {
                                        name: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "struct";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    }[];
                                };
                            } | {
                                kind: "integer";
                                value: {};
                            } | {
                                kind: "float";
                                value: {};
                            } | {
                                kind: "double";
                                value: {};
                            } | {
                                kind: "date";
                                value: {};
                            } | {
                                kind: "geopoint";
                                value: {};
                            } | /*elided*/ any | {
                                kind: "struct";
                                value: {
                                    fields: {
                                        name: string;
                                        displayName: string;
                                        type: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        description?: string | undefined;
                                        deprecated?: {
                                            message: string;
                                        } | undefined;
                                    }[];
                                };
                            } | /*elided*/ any | {
                                kind: "objectReference";
                                value: {
                                    objectType: string;
                                };
                            } | {
                                kind: "unknown";
                                value: {};
                            };
                        };
                    } | {
                        kind: "struct";
                        value: {
                            fields: {
                                name: string;
                                displayName: string;
                                type: {
                                    kind: "string";
                                    value: {
                                        constraint?: {
                                            kind: "regex";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "enum";
                                            value: /*elided*/ any;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "boolean";
                                    value: {};
                                } | {
                                    kind: "map";
                                    value: {
                                        keyType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        valueType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "result";
                                    value: {
                                        okType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                        errType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "list";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | {
                                    kind: "ref";
                                    value: {
                                        name: string;
                                    };
                                } | {
                                    kind: "timestamp";
                                    value: {};
                                } | {
                                    kind: "attachment";
                                    value: {
                                        constraint?: {
                                            size?: /*elided*/ any | undefined;
                                            content?: /*elided*/ any | undefined;
                                        } | undefined;
                                        meta?: {
                                            [x: string]: unknown;
                                        } | undefined;
                                    };
                                } | {
                                    kind: "union";
                                    value: {
                                        variants: {
                                            name: string;
                                            type: /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any | /*elided*/ any;
                                        }[];
                                    };
                                } | {
                                    kind: "integer";
                                    value: {};
                                } | {
                                    kind: "float";
                                    value: {};
                                } | {
                                    kind: "double";
                                    value: {};
                                } | {
                                    kind: "date";
                                    value: {};
                                } | {
                                    kind: "geopoint";
                                    value: {};
                                } | {
                                    kind: "list";
                                    value: {
                                        elementType: {
                                            kind: "string";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "boolean";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "map";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "result";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "ref";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "timestamp";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "attachment";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "union";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "integer";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "float";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "double";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "date";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "geopoint";
                                            value: /*elided*/ any;
                                        } | /*elided*/ any | /*elided*/ any | /*elided*/ any | {
                                            kind: "objectReference";
                                            value: /*elided*/ any;
                                        } | {
                                            kind: "unknown";
                                            value: /*elided*/ any;
                                        };
                                    };
                                } | /*elided*/ any | /*elided*/ any | {
                                    kind: "objectReference";
                                    value: {
                                        objectType: string;
                                    };
                                } | {
                                    kind: "unknown";
                                    value: {};
                                };
                                description?: string | undefined;
                                deprecated?: {
                                    message: string;
                                } | undefined;
                            }[];
                        };
                    } | /*elided*/ any | {
                        kind: "objectReference";
                        value: {
                            objectType: string;
                        };
                    } | {
                        kind: "unknown";
                        value: {};
                    };
                };
            } | {
                kind: "objectReference";
                value: {
                    objectType: string;
                };
            } | {
                kind: "unknown";
                value: {};
            };
            description?: string | undefined;
            deprecated?: {
                message: string;
            } | undefined;
        }[];
        description?: string | undefined;
        deprecated?: {
            message: string;
        } | undefined;
    }[];
    linkTypes: never[];
    actionTypes: never[];
    queryFunctionTypes: never[];
    contextType: {
        kind: "struct";
        value: {
            fields: {
                name: "user";
                displayName: "User";
                type: {
                    kind: "objectReference";
                    value: {
                        objectType: "FoundryUser";
                    };
                };
            }[];
        };
    };
};
export declare function createFoundryAdminOntologyRoute(options?: {
    ontologyId?: string;
}): FoundryOntologyRoute;
//# sourceMappingURL=createFoundryAdminOntologyRoute.d.ts.map