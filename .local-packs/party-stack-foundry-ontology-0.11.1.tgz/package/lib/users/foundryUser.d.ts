import { type Lens, type ObjectTypeDef } from "@party-stack/ontology";
import type * as v from "@party-stack/ontology/values";
export declare const foundryUserObjectType: ObjectTypeDef;
/**
 * Foundry exposes profile pictures through a mutable endpoint but does not
 * include presence or version metadata on User records. The hourly bucket acts
 * as a pseudo-version so BlobManager can retain its immutable-ID cache model:
 * user rows loaded in the same hour share cached content, while a later row
 * load produces a new ID and refetches the picture. Missing pictures are stored
 * as empty blobs for that bucket and retried when the ID rotates.
 */
export declare function foundryUserProfilePictureAttachment(userId: string): v.attachment;
export declare function decodeFoundryUserProfilePictureAttachment(attachmentId: string): string | undefined;
export declare function createFoundryUserObjectType(objectType: string, lens: Lens): ObjectTypeDef;
//# sourceMappingURL=foundryUser.d.ts.map