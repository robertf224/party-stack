export {};
//# sourceMappingURL=foundryUser.test.d.ts.map