import type { Lens } from "@party-stack/ontology";
import type { FoundryUsersIntegration } from "../adapter/createFoundryOntologyBackendAdapter.js";
export declare function createFoundryUsersIntegration(options: {
    objectType: string;
    lens: Lens;
}): FoundryUsersIntegration;
//# sourceMappingURL=createFoundryUsersIntegration.d.ts.map