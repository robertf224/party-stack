import { type BackendConnectionAdapterProvider, type Connection } from "@party-stack/connections";
import type { BrowserAuthenticationPresentation } from "@party-stack/runtime";
export interface FoundryOAuthConnectionOptions {
    clientId: string;
    redirectUrl: string;
    scopes?: string[];
    fetch?: typeof globalThis.fetch;
    dangerouslyPersistSecrets?: boolean;
}
export interface FoundryClientCredentialsConnectionOptions {
    clientId: string;
    clientSecret: string;
    userId?: string;
    scopes?: string[];
    fetch?: typeof globalThis.fetch;
}
export interface CreateFoundryConnectionAdapterOptions {
    baseUrl: string;
    oauth?: FoundryOAuthConnectionOptions;
    clientCredentials?: FoundryClientCredentialsConnectionOptions;
    token?: string;
}
export interface FoundryAuthenticationClient {
    completeOAuthRedirect(url: string): Promise<Connection<"active"> | undefined>;
    signIn: {
        oauth(options?: {
            browserPresentation?: BrowserAuthenticationPresentation;
        }): Promise<Connection<"active">>;
        clientCredentials(): Promise<Connection<"active">>;
        apiToken(options?: {
            token?: string;
        }): Promise<Connection<"active">>;
    };
}
export declare function createFoundryConnectionAdapter(options: CreateFoundryConnectionAdapterOptions): BackendConnectionAdapterProvider<FoundryAuthenticationClient>;
//# sourceMappingURL=connection.d.ts.map