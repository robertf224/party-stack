export declare function chunk<T>(items: T[], size: number): T[][];
//# sourceMappingURL=chunk.d.ts.map