export declare function toOntologyActionTypeName(foundryActionTypeName: string): string;
export declare function toFoundryActionTypeName(ontologyActionTypeName: string): string;
//# sourceMappingURL=actionTypeName.d.ts.map