export {};
//# sourceMappingURL=actionTypeName.test.d.ts.map