import type { OntologyIR } from "../ir/generated/types.js";
export interface GenerateLiveOpts {
    ontologyImportPath: string;
    ontologyTypesImportPath: string;
    ontologyRuntimeImportPath: string;
    ontologyTypeName: string;
    outputFactoryName: string;
}
export declare function generateLive(ir: OntologyIR, opts: GenerateLiveOpts): string;
//# sourceMappingURL=live.d.ts.map