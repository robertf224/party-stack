export {};
//# sourceMappingURL=ontology.test.d.ts.map