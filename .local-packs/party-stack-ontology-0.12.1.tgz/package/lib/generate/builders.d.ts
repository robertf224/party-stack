import type { OntologyIR } from "../ir/index.js";
export interface GenerateBuildersOpts {
    /** The name of the main export (e.g., "o" for `o.string()`). */
    exportName: string;
    /** If set, promotes this union type's variants to the top level of the export. */
    promoted?: string;
}
export declare function generateBuilders(schema: Pick<OntologyIR, "types">, opts: GenerateBuildersOpts): string;
//# sourceMappingURL=builders.d.ts.map