import type { OntologyIR, ObjectTypeDef, TypeDef } from "../ir/generated/types.js";
export interface GenerateTypeDefinitionsOpts {
    valuesImportPath?: string;
    objectTypes?: ReadonlyMap<string, ObjectTypeDef>;
}
interface GenerateTypeContext {
    objectTypes?: ReadonlyMap<string, ObjectTypeDef>;
}
export declare function generateForTypeDef(type: TypeDef, ctx?: GenerateTypeContext): string;
export declare function generateTypeDefinitions(schema: Pick<OntologyIR, "types">, opts?: GenerateTypeDefinitionsOpts): string;
export interface GenerateTypesOpts {
    outputTypeName?: string;
}
export declare function generateTypes(ir: OntologyIR, opts?: GenerateTypesOpts): string;
export {};
//# sourceMappingURL=types.d.ts.map