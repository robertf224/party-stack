import type { Deprecation } from "../../ir/index.js";
import type { JSDocStructure, OptionalKind } from "ts-morph";
export declare function buildJsDocs(opts: {
    description?: string;
    deprecated?: Deprecation;
}): OptionalKind<JSDocStructure>[] | undefined;
//# sourceMappingURL=buildJsDocs.d.ts.map