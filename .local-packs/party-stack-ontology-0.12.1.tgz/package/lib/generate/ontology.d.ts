import type { OntologyIR } from "../ir/generated/types.js";
export interface GenerateOntologyOpts {
    ontologyImportPath?: string;
}
export declare function generateOntology(ir: OntologyIR, opts?: GenerateOntologyOpts): string;
//# sourceMappingURL=ontology.d.ts.map