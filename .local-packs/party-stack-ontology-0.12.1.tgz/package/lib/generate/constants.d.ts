import type { OntologyIR } from "../ir/generated/types.js";
export declare function generateConstants(schema: Pick<OntologyIR, "types">): string;
//# sourceMappingURL=constants.d.ts.map