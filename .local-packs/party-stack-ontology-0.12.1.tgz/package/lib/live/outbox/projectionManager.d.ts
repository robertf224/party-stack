import type { OntologyOutboxEntry } from "./types.js";
export interface OutboxProjection {
    settle(error?: Error): void;
}
export declare class OutboxProjectionManager {
    private readonly project;
    private desired;
    private readonly projections;
    private readonly installedFingerprints;
    private readonly versions;
    private tail;
    private closed;
    private disabledError;
    constructor(project: ((entry: OntologyOutboxEntry) => Promise<OutboxProjection | undefined>) | undefined);
    get error(): Error | undefined;
    restore(entries: readonly OntologyOutboxEntry[]): Promise<void>;
    reconcile(entries: readonly OntologyOutboxEntry[]): Promise<void>;
    ensure(entry: OntologyOutboxEntry): Promise<void>;
    discard(id: string, error?: Error): Promise<void>;
    close(): Promise<void>;
    private schedule;
    private applyDesired;
    private disable;
    private firstDivergence;
    private install;
    private invalidate;
    private settle;
}
//# sourceMappingURL=projectionManager.d.ts.map