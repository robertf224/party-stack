export {};
//# sourceMappingURL=createOntologyOutbox.test.d.ts.map