import type { CoordinationHost, CoordinationServiceServer } from "@party-stack/runtime";
import { OntologyOutboxRepository } from "./repository.js";
import { type OutboxCoordinationService } from "./service.js";
export declare function serveOntologyOutbox(host: CoordinationHost, repository: OntologyOutboxRepository): CoordinationServiceServer<OutboxCoordinationService>;
//# sourceMappingURL=outboxService.d.ts.map