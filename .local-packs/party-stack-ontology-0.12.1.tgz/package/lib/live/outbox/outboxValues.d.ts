import type { OntologyActionRequest, OntologyOutboxEntry } from "./types.js";
export declare function encodeOutboxValue(value: unknown): unknown;
export declare function decodeOutboxValue(value: unknown): unknown;
export declare function encodeOutboxRequest(request: OntologyActionRequest): OntologyActionRequest;
export declare function decodeOutboxRequest(request: OntologyActionRequest): OntologyActionRequest;
export declare function decodeOutboxEntry(entry: OntologyOutboxEntry): OntologyOutboxEntry;
//# sourceMappingURL=outboxValues.d.ts.map