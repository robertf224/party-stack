import { type RuntimeAdapter } from "@party-stack/runtime";
import { type Operation, type Task } from "effection";
import type { ConnectionMonitor } from "@party-stack/connections";
import { type OutboxProjection } from "./projectionManager.js";
import type { OntologyOutbox, OntologyOutboxEntry } from "./types.js";
import type { Collection } from "@tanstack/db";
export type { OutboxProjection } from "./projectionManager.js";
export interface CreateOntologyOutboxOptions {
    runtime: RuntimeAdapter;
    execute(entry: OntologyOutboxEntry): Promise<unknown>;
    project?(entry: OntologyOutboxEntry): Promise<OutboxProjection | undefined>;
    failureStrategy?: "pause" | "discard-all";
    maxRetries?: number;
    connection?: ConnectionMonitor;
}
export declare function useOntologyOutbox(options: CreateOntologyOutboxOptions, collection?: Collection<OntologyOutboxEntry, string>): Operation<OntologyOutbox>;
export interface StartedOntologyOutbox extends OntologyOutbox {
    readonly task: Task<void>;
}
export declare function createOntologyOutbox(options: CreateOntologyOutboxOptions): StartedOntologyOutbox;
//# sourceMappingURL=createOntologyOutbox.d.ts.map