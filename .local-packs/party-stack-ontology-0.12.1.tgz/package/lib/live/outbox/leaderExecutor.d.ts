import { type ConnectionMonitor } from "@party-stack/connections";
import { type CoordinationServiceClient, type RuntimeAdapter } from "@party-stack/runtime";
import { type Operation, type Stream } from "effection";
import { type OntologyOutboxEntry } from "./types.js";
import type { OutboxCoordinationService } from "./service.js";
export interface OutboxLeaderOptions {
    runtime: RuntimeAdapter;
    service: CoordinationServiceClient<OutboxCoordinationService>;
    wake: Stream<void, never>;
    failureStrategy: "pause" | "discard-all";
    maxRetries: number;
    retryDelayMs: number;
    execute(entry: OntologyOutboxEntry): Promise<unknown>;
    connection?: ConnectionMonitor;
}
export declare function useOutboxLeader(options: OutboxLeaderOptions): Operation<void>;
export declare function runOutboxLeader(signal: AbortSignal, options: OutboxLeaderOptions): Promise<void>;
//# sourceMappingURL=leaderExecutor.d.ts.map