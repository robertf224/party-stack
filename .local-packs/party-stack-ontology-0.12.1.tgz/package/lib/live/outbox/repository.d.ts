import { type Collection } from "@tanstack/db";
import type { OutboxErrorDetails } from "./service.js";
import type { OntologyActionRequest, OntologyOutboxEntry } from "./types.js";
export declare function requestFingerprint(request: OntologyActionRequest): string;
export declare class OntologyOutboxRepository {
    readonly collection: Collection<OntologyOutboxEntry, string>;
    constructor(collection: Collection<OntologyOutboxEntry, string>);
    preload(): Promise<void>;
    get(id: string): OntologyOutboxEntry | undefined;
    entries(): Promise<OntologyOutboxEntry[]>;
    enqueue(proposed: OntologyOutboxEntry): Promise<OntologyOutboxEntry>;
    edit(id: string, request: OntologyActionRequest): Promise<OntologyOutboxEntry>;
    remove(id: string): Promise<void>;
    retry(id: string): Promise<void>;
    recover(failureStrategy: "pause" | "discard-all", maxRetries: number): Promise<OntologyOutboxEntry[]>;
    claim(): Promise<OntologyOutboxEntry | undefined>;
    nextRetryAt(): Promise<number | undefined>;
    complete(id: string, executionId: string): Promise<void>;
    fail(id: string, executionId: string, retryable: boolean, error: OutboxErrorDetails, retryAt?: number): Promise<OntologyOutboxEntry>;
    discardAll(id: string, executionId: string): Promise<OntologyOutboxEntry[]>;
    discardFrom(id: string): Promise<OntologyOutboxEntry[]>;
    private head;
    private nextSequence;
    private assertCurrentExecution;
    private update;
    private delete;
    private deleteEntries;
}
//# sourceMappingURL=repository.d.ts.map