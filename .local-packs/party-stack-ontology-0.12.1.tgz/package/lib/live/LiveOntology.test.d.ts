export {};
//# sourceMappingURL=LiveOntology.test.d.ts.map