import type { OntologyIR } from "../../ir/index.js";
import type { LiveOntologyObjectQueries } from "../objects/createLiveOntologyObjectQueries.js";
export declare class UnavailableLiveOntologyPrefillError extends Error {
    constructor(message: string);
}
export declare class ForbiddenLiveOntologyPrefillError extends Error {
    constructor(message: string);
}
export type ResolvedActionParameterPrefill = {
    status: "resolved";
    parameter: string;
    value: unknown;
} | {
    status: "missing";
    parameter: string;
} | {
    status: "ambiguous";
    parameter: string;
} | {
    status: "forbidden";
    parameter: string;
    message: string;
} | {
    status: "unavailable";
    parameter: string;
    message: string;
};
export declare function resolveActionParameterPrefills(opts: {
    ir: OntologyIR;
    actionType: string;
    parameters: Record<string, unknown>;
    objectQueries: LiveOntologyObjectQueries;
}): Promise<ResolvedActionParameterPrefill[]>;
export declare function assertPrefillsAvailable(results: ResolvedActionParameterPrefill[]): void;
//# sourceMappingURL=resolveActionParameterPrefills.d.ts.map