import type { BlobManager } from "@party-stack/blobs";
import type { OntologyIR } from "../../ir/index.js";
import type { OntologyAttachmentIdMapping, OntologyAttachmentUpload, OntologyBackendAdapter } from "../OntologyBackendAdapter.js";
export interface PreparedActionParameters {
    parameters: Record<string, unknown>;
    attachmentUploads: OntologyAttachmentUpload[];
    attachmentIdMappings: OntologyAttachmentIdMapping[];
}
export declare function prepareActionParameters(opts: {
    ir: OntologyIR;
    actionTypeName: string;
    parameters: Record<string, unknown>;
    backendAdapter: OntologyBackendAdapter;
    blobManager?: BlobManager;
}): Promise<PreparedActionParameters>;
//# sourceMappingURL=prepareActionParameters.d.ts.map