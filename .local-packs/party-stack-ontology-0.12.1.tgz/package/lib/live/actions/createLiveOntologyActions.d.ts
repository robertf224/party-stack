import type { BlobManager } from "@party-stack/blobs";
import type { ConnectionMonitor } from "@party-stack/connections";
import type { RuntimeAdapter } from "@party-stack/runtime";
import type { LiveOntologyAction } from "./createLiveOntologyAction.js";
import type { OntologyIR } from "../../ir/index.js";
import type { LiveOntologyWrites } from "../LiveOntology.js";
import type { OntologyCollection } from "../objects/createLiveOntologyObjectCollection.js";
import type { OntologyObject } from "../objects/OntologyObject.js";
import type { OntologyBackendAdapter } from "../OntologyBackendAdapter.js";
import type { OntologyOutbox } from "../outbox/types.js";
export interface LiveOntologyActionsSubsystem {
    actions: Record<string, LiveOntologyAction>;
    outbox: OntologyOutbox;
}
export declare function createLiveOntologyActions(options: {
    ir: OntologyIR;
    backendAdapter: OntologyBackendAdapter;
    runtime: RuntimeAdapter;
    context: Record<string, unknown>;
    objects: Record<string, OntologyCollection<OntologyObject>>;
    blobManager: BlobManager;
    writes?: LiveOntologyWrites;
    connection?: ConnectionMonitor;
}): LiveOntologyActionsSubsystem;
//# sourceMappingURL=createLiveOntologyActions.d.ts.map