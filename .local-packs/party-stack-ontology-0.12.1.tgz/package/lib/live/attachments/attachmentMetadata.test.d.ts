export {};
//# sourceMappingURL=attachmentMetadata.test.d.ts.map