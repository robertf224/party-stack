import type { OntologyAttachmentsAdapter } from "../OntologyBackendAdapter.js";
export declare const unsupportedOntologyAttachmentsAdapter: OntologyAttachmentsAdapter;
//# sourceMappingURL=unsupportedOntologyAttachmentsAdapter.d.ts.map