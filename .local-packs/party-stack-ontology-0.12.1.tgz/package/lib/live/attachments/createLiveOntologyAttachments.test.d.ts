export {};
//# sourceMappingURL=createLiveOntologyAttachments.test.d.ts.map