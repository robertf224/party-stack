import type { ObjectTypeDef, OntologyIR } from "../../ir/index.js";
export declare function decorateObjectAttachmentSources(opts: {
    ir: OntologyIR;
    objectType: ObjectTypeDef;
    object: Record<string, unknown>;
}): Record<string, unknown>;
//# sourceMappingURL=attachmentSources.d.ts.map