import type { BlobManager } from "@party-stack/blobs";
import * as v from "../../utils/values.js";
import type { AttachmentMetadata, AttachmentMetadataSelection } from "./types.js";
import type { OntologyIR } from "../../ir/index.js";
import type { OntologyAttachmentCreateTarget } from "../../utils/targets.js";
import type { OntologyAttachmentsAdapter } from "../OntologyBackendAdapter.js";
export interface LiveOntologyEagerAttachmentCreation {
    attachment: v.attachment;
    isMaterialized?: Promise<void>;
}
interface LiveOntologyAttachmentCreateOptions {
    target?: OntologyAttachmentCreateTarget;
    eager?: boolean;
}
interface AttachmentOntologyDefinition {
    objectTypes: Record<string, Record<string, unknown>>;
    actionTypes: Record<string, {
        parameters: Record<string, unknown>;
    }>;
}
type ExtractAttachment<Value> = Value extends v.attachment<infer Type> ? v.attachment<Type> : NonNullable<Value> extends ReadonlyArray<infer Element> ? ExtractAttachment<Element> : never;
type AttachmentAtTarget<Ontology extends AttachmentOntologyDefinition, Target> = string extends keyof Ontology["objectTypes"] ? v.attachment : Target extends {
    kind: "objectProperty";
    objectType: infer ObjectType;
    property: infer Property;
} ? ObjectType extends keyof Ontology["objectTypes"] ? Property extends keyof Ontology["objectTypes"][ObjectType] ? ExtractAttachment<Ontology["objectTypes"][ObjectType][Property]> : never : never : Target extends {
    kind: "actionParameter";
    actionType: infer ActionType;
    parameter: infer Parameter;
} ? ActionType extends keyof Ontology["actionTypes"] ? Parameter extends keyof Ontology["actionTypes"][ActionType]["parameters"] ? ExtractAttachment<Ontology["actionTypes"][ActionType]["parameters"][Parameter]> : never : never : v.attachment;
type LiveOntologyAttachmentCreateResult<Ontology extends AttachmentOntologyDefinition, Options extends LiveOntologyAttachmentCreateOptions | undefined> = {
    attachment: Options extends {
        target: infer Target;
    } ? AttachmentAtTarget<Ontology, Target> : v.attachment;
} & (Options extends {
    eager: true;
} ? {
    isMaterialized?: Promise<void>;
} : {
    isMaterialized?: never;
});
export interface LiveOntologyAttachments<Ontology extends AttachmentOntologyDefinition = AttachmentOntologyDefinition> {
    create: <const Options extends LiveOntologyAttachmentCreateOptions | undefined = undefined>(blob: Blob | File, opts?: Options) => Promise<LiveOntologyAttachmentCreateResult<Ontology, Options>>;
    metadata: {
        <Type extends string>(attachment: v.attachment<Type>): Promise<AttachmentMetadata<Type>>;
        <Type extends string, const Selection extends AttachmentMetadataSelection<Type>>(attachment: v.attachment<Type>, options: {
            select: Selection;
        }): Promise<AttachmentMetadata<Type, Selection[number]>>;
    };
    blob: (attachment: v.attachment) => Promise<Blob>;
}
export declare function createLiveOntologyAttachments<Ontology extends AttachmentOntologyDefinition = AttachmentOntologyDefinition>(opts: {
    ir: OntologyIR;
    attachmentsAdapter: OntologyAttachmentsAdapter;
    blobManager: BlobManager;
}): LiveOntologyAttachments<Ontology>;
export {};
//# sourceMappingURL=createLiveOntologyAttachments.d.ts.map