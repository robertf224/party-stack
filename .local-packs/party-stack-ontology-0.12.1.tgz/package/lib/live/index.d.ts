export * from "./OntologyBackendAdapter.js";
export * from "./LiveOntology.js";
export type { AttachmentMetadata, PartialAttachmentMetadata, } from "./attachments/types.js";
export * from "./mutators/types.js";
export { createReadTx, } from "./mutators/createMutatorTx.js";
export * from "./mutators/runOptimisticAction.js";
export * from "./outbox/types.js";
//# sourceMappingURL=index.d.ts.map