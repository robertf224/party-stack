export declare function ontologyObjectCollectionId(owner: string, ontologyId: string, objectType: string): string;
//# sourceMappingURL=ontologyObjectCollectionId.d.ts.map