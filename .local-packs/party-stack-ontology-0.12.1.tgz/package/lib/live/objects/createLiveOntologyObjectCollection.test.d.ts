export {};
//# sourceMappingURL=createLiveOntologyObjectCollection.test.d.ts.map