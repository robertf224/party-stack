import type { OntologyCollection } from "./createLiveOntologyObjectCollection.js";
import type { OntologyObject } from "./OntologyObject.js";
import type { OntologyIR } from "../../ir/index.js";
export declare class AmbiguousLiveOntologyObjectQueryError extends Error {
    constructor(message: string);
}
export declare class ForbiddenLiveOntologyObjectQueryError extends Error {
    constructor(message: string);
}
export interface LiveOntologyObjectQueries {
    getByPrimaryKey(opts: {
        objectType: string;
        primaryKey: string | number;
        properties?: string[];
    }): Promise<Record<string, unknown> | undefined>;
    findMany(opts: {
        objectType: string;
        equals: Record<string, unknown>;
        properties?: string[];
        limit?: number;
    }): Promise<Record<string, unknown>[]>;
    findOne(opts: {
        objectType: string;
        equals: Record<string, unknown>;
        properties?: string[];
    }): Promise<Record<string, unknown> | undefined>;
}
export declare function createLiveOntologyObjectQueries(opts: {
    ir: OntologyIR;
    objects: Record<string, OntologyCollection<OntologyObject>>;
}): LiveOntologyObjectQueries;
//# sourceMappingURL=createLiveOntologyObjectQueries.d.ts.map