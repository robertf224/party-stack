export type OntologyObject = Record<string, unknown>;
//# sourceMappingURL=OntologyObject.d.ts.map