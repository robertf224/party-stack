import { type RuntimeAdapter } from "@party-stack/runtime";
import { type Collection } from "@tanstack/db";
import type { OntologyIR } from "../../ir/index.js";
import type { OntologyBackendAdapter } from "../OntologyBackendAdapter.js";
import type { OntologyObject } from "./OntologyObject.js";
export type OntologyCollection<T extends OntologyObject> = Collection<T>;
export declare function createLiveOntologyObjectCollection(opts: {
    ir: OntologyIR;
    objectType: OntologyIR["objectTypes"][number];
    backendAdapter: OntologyBackendAdapter;
    runtime: RuntimeAdapter;
    persistObjects: boolean;
}): OntologyCollection<OntologyObject>;
//# sourceMappingURL=createLiveOntologyObjectCollection.d.ts.map