import type { Collection } from "@tanstack/db";
export declare function waitForCollectionsReady(collections: Iterable<Collection<Record<string, unknown>, string | number>>): Promise<void>;
//# sourceMappingURL=waitForCollectionReady.d.ts.map