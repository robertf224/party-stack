import type { OntologyReadTx } from "./mutators/types.js";
import type { Expression, ObjectTypeDef, OntologyIR, ValueReferenceExpression } from "../ir/index.js";
export declare function evaluateExpression(options: {
    ir: OntologyIR;
    actionTypeName: string;
    expression: Expression;
    resolveParameter: (parameterName: string) => Promise<unknown>;
    context: Record<string, unknown>;
    tx: OntologyReadTx;
}): Promise<unknown>;
export declare function resolveActionParameters(options: {
    ir: OntologyIR;
    actionTypeName: string;
    initialParameters: Record<string, unknown>;
    context: Record<string, unknown>;
    tx: OntologyReadTx;
}): Promise<Record<string, unknown>>;
export declare function getObjectReferenceObjectType(ir: OntologyIR, actionTypeName: string, reference: ValueReferenceExpression): ObjectTypeDef;
//# sourceMappingURL=expression.d.ts.map