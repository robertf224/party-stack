import { type RuntimeAdapterProvider } from "@party-stack/runtime";
import type { ConnectionMonitor } from "@party-stack/connections";
import { type LiveOntologyAttachments } from "./attachments/createLiveOntologyAttachments.js";
import type { LiveOntologyAction } from "./actions/createLiveOntologyAction.js";
import type { OntologyMutatorRegistry } from "./mutators/types.js";
import type { OntologyCollection } from "./objects/createLiveOntologyObjectCollection.js";
import type { OntologyObject } from "./objects/OntologyObject.js";
import type { OntologyBackendAdapterProvider } from "./OntologyBackendAdapter.js";
import type { OntologyOutbox } from "./outbox/types.js";
import type { OntologyIR } from "../ir/index.js";
export type { LiveOntologyAction, LiveOntologyActionOptions } from "./actions/createLiveOntologyAction.js";
export type { LiveOntologyAttachments } from "./attachments/createLiveOntologyAttachments.js";
export type { OntologyCollection } from "./objects/createLiveOntologyObjectCollection.js";
export type LiveOntologyWriteMode = "direct" | "outbox";
export type LiveOntologyWriteVisibility = "confirmed" | "optimistic";
export type LiveOntologyOutboxFailureStrategy = "pause" | "discard-all";
export interface LiveOntologyOutboxOptions {
    failureStrategy?: LiveOntologyOutboxFailureStrategy;
    maxRetries?: number;
}
export interface LiveOntologyWrites {
    defaultMode?: LiveOntologyWriteMode;
    defaultVisibility?: LiveOntologyWriteVisibility;
    mutators?: OntologyMutatorRegistry;
    outbox?: LiveOntologyOutboxOptions;
}
export interface OntologyDefinition {
    context?: Record<string, unknown>;
    objectTypes: Record<string, OntologyObject>;
    actionTypes: Record<string, {
        parameters: Record<string, unknown>;
    }>;
    queryFunctionTypes: Record<string, {
        parameters: Record<string, unknown>;
        returnType: unknown;
    }>;
}
type OntologyContext<Ontology extends OntologyDefinition> = Ontology extends {
    context: infer Context extends Record<string, unknown>;
} ? Context : Record<string, unknown>;
export type LiveOntologyQueryFunction<Parameters extends Record<string, unknown> = Record<string, unknown>, Return = unknown> = (parameters: Parameters) => Promise<Return>;
export type LiveOntologyObjects<ObjectTypes extends OntologyDefinition["objectTypes"] = OntologyDefinition["objectTypes"]> = {
    [ObjectTypeName in keyof ObjectTypes]: OntologyCollection<ObjectTypes[ObjectTypeName]>;
};
export type LiveOntologyActions<ActionTypes extends OntologyDefinition["actionTypes"]> = {
    [ActionTypeName in keyof ActionTypes]: LiveOntologyAction<ActionTypes[ActionTypeName]["parameters"]>;
};
export type LiveOntologyQueryFunctions<QueryFunctionTypes extends OntologyDefinition["queryFunctionTypes"]> = {
    [QueryFunctionTypeName in keyof QueryFunctionTypes]: LiveOntologyQueryFunction<QueryFunctionTypes[QueryFunctionTypeName]["parameters"], QueryFunctionTypes[QueryFunctionTypeName]["returnType"]>;
};
export interface LiveOntology<Ontology extends OntologyDefinition = OntologyDefinition> {
    readonly ir: OntologyIR;
    readonly context: OntologyContext<Ontology>;
    /**
     * Resolves once outbox and blob metadata subsystems have finished starting.
     * Object collections remain on-demand unless explicitly preloaded.
     */
    readonly ready: Promise<void>;
    objects: LiveOntologyObjects<Ontology["objectTypes"]>;
    actions: LiveOntologyActions<Ontology["actionTypes"]>;
    queryFunctions: LiveOntologyQueryFunctions<Ontology["queryFunctionTypes"]>;
    attachments: LiveOntologyAttachments<Ontology>;
    outbox: OntologyOutbox;
    cleanup: () => Promise<void>;
    destroy: () => Promise<void>;
}
export interface CreateLiveOntologyOpts<Context extends Record<string, unknown> = Record<string, unknown>> {
    id?: string;
    ir: OntologyIR;
    backend: OntologyBackendAdapterProvider<NoInfer<Context>>;
    runtime?: RuntimeAdapterProvider;
    persistObjects?: boolean;
    writes?: LiveOntologyWrites;
    context?: Context;
    connection?: ConnectionMonitor;
}
/**
 * Waits for LiveOntology subsystems required before safe use.
 * Starts on-demand object collection sync without loading subsets.
 */
export declare function waitForLiveOntologyReady(ontology: LiveOntology): Promise<void>;
export declare function createLiveOntology<Ontology extends OntologyDefinition = OntologyDefinition, Context extends Record<string, unknown> = Record<string, unknown>>(opts: CreateLiveOntologyOpts<Context>): Promise<LiveOntology<Ontology>>;
//# sourceMappingURL=LiveOntology.d.ts.map