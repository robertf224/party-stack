import type { OntologyMutatorRegistry } from "./types.js";
import type { OntologyIR } from "../../ir/index.js";
import type { OntologyCollection } from "../objects/createLiveOntologyObjectCollection.js";
import type { OntologyObject } from "../objects/OntologyObject.js";
import type { Transaction } from "@tanstack/db";
export declare function runOptimisticAction(options: {
    transaction: Transaction;
    ir: OntologyIR;
    actionTypeName: string;
    parameters: Record<string, unknown>;
    context: Record<string, unknown>;
    objects: Record<string, OntologyCollection<OntologyObject>>;
    mutators?: OntologyMutatorRegistry;
}): Promise<void>;
//# sourceMappingURL=runOptimisticAction.d.ts.map