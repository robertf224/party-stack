import type { OntologyMutatorObjects, OntologyMutatorTx } from "./types.js";
import type { OntologyIR } from "../../ir/index.js";
export declare function applyActionLogicToMutatorTx(options: {
    ir: OntologyIR;
    actionTypeName: string;
    parameters: Record<string, unknown>;
    context: Record<string, unknown>;
    objects: OntologyMutatorObjects;
    tx: OntologyMutatorTx;
}): Promise<void>;
//# sourceMappingURL=OntologyEdits.d.ts.map