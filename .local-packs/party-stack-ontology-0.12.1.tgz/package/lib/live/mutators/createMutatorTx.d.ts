import { type Transaction } from "@tanstack/db";
import type { OntologyMutatorObjects, OntologyMutatorTx, OntologyReadTx } from "./types.js";
export declare function createReadTx(objects: OntologyMutatorObjects): OntologyReadTx;
export declare function createMutatorTx(options: {
    transaction: Transaction;
    objects: OntologyMutatorObjects;
    primaryKeys?: Record<string, string>;
}): OntologyMutatorTx;
//# sourceMappingURL=createMutatorTx.d.ts.map