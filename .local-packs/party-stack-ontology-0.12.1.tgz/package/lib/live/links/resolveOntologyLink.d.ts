import type { LinkTypeDef, OntologyIR } from "../../ir/index.js";
export declare class OntologyLinkError extends Error {
    constructor(message: string, opts?: {
        cause?: unknown;
    });
}
export type ResolvedOntologyLink = {
    link: LinkTypeDef;
    /** Object type at the far end of this traversal. */
    targetObjectType: string;
    /** Side API name used when talking to a backend from the current object. */
    sideName: string;
    /** Inverse side API name. */
    inverseSideName: string;
    foreignKey?: string;
    /** True when the foreign key property lives on the current (source) object. */
    foreignKeyOnCurrentObject: boolean;
    cardinality: "one" | "many";
};
/**
 * Finds a link by stable id, or by the outbound side API name from `sourceObjectType`.
 *
 * A side describes the role of objects on that side. From the source object, callers use
 * `target.name`; from the target object, callers use `source.name`.
 */
export declare function findLinkType(ir: OntologyIR, sourceObjectType: string, linkRef: {
    sideName: string;
} | {
    id: string;
}): LinkTypeDef | undefined;
export declare function resolveOntologyLink(ir: OntologyIR, sourceObjectType: string, linkRef: {
    sideName: string;
} | {
    id: string;
}): ResolvedOntologyLink;
export declare function normalizeLinkRef(link: string | {
    sideName: string;
} | {
    id: string;
}): {
    sideName: string;
} | {
    id: string;
};
//# sourceMappingURL=resolveOntologyLink.d.ts.map