import type { LinkTypeDef, OntologyIR } from "../../ir/index.js";
import type { OntologyCollection } from "../objects/createLiveOntologyObjectCollection.js";
import type { OntologyObject } from "../objects/OntologyObject.js";
import type { OntologyBackendAdapter } from "../OntologyBackendAdapter.js";
export type LiveLinkCardinality = "one" | "many";
export type LiveLinkResolutionKind = "foreignKey" | "backend";
export declare class UnsupportedLiveOntologyLinkError extends Error {
    constructor(message: string);
}
export declare class ForbiddenLiveOntologyLinkError extends Error {
    constructor(message: string);
}
export declare class MissingLiveOntologyLinkError extends Error {
    constructor(message: string);
}
export interface ResolvedLinkHop {
    link: LinkTypeDef;
    fromObjectType: string;
    toObjectType: string;
    cardinality: LiveLinkCardinality;
    resolution: LiveLinkResolutionKind;
    foreignKeyProperty?: string;
    foreignKeyOnFromObject: boolean;
    apiName: string;
}
export interface LiveOntologyLinks {
    findLink(fromObjectType: string, linkIdentifier: string): LinkTypeDef | undefined;
    compilePath(fromObjectType: string, path: string[], options?: {
        allowToMany?: boolean;
    }): ResolvedLinkHop[];
    resolveOne(opts: {
        fromObjectType: string;
        primaryKey: string | number;
        path: string[];
        properties?: string[];
    }): Promise<Record<string, unknown> | undefined>;
    resolveMany(opts: {
        fromObjectType: string;
        primaryKey: string | number;
        path: string[];
        properties?: string[];
    }): Promise<Record<string, unknown>[]>;
}
export declare function findLinkType(ir: OntologyIR, sourceObjectType: string, linkIdentifier: string): LinkTypeDef | undefined;
export declare function resolveLinkHop(ir: OntologyIR, fromObjectType: string, linkIdentifier: string): ResolvedLinkHop;
export declare function compileLinkPath(ir: OntologyIR, fromObjectType: string, path: string[], options?: {
    allowToMany?: boolean;
}): ResolvedLinkHop[];
export declare function createLiveOntologyLinks(opts: {
    ir: OntologyIR;
    objects: Record<string, OntologyCollection<OntologyObject>>;
    backendAdapter: OntologyBackendAdapter;
}): LiveOntologyLinks;
//# sourceMappingURL=createLiveOntologyLinks.d.ts.map