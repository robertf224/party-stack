export {};
//# sourceMappingURL=resolveOntologyLink.test.d.ts.map