import type { Lens, ObjectTypeDef } from "./ir/index.js";
export interface ApplyObjectTypeLensOptions {
    name: string;
    displayName?: string;
    pluralDisplayName?: string;
}
export declare function applyLensToObjectType(source: ObjectTypeDef, lens: Lens, options: ApplyObjectTypeLensOptions): ObjectTypeDef;
export declare function applyLensToObject<Source extends Record<string, unknown>, Target extends Record<string, unknown>>(source: Source, lens: Lens): Target;
/**
 * Maps a target-model field path back to its source-model path so simple
 * target-side queries can be pushed through a lens. This is path provenance,
 * not a general inverse for values or schemas: selected-out data cannot be
 * reconstructed. A future lens query compiler can use this as its direct-path
 * primitive while handling computed/list operations, local evaluation, and
 * unsupported query rewrites at the expression or query-plan level.
 */
export declare function mapTargetPathToSourceWithLens(path: readonly string[], lens: Lens): string[];
//# sourceMappingURL=lenses.d.ts.map