import type { OntologyIR } from "../ir/generated/types.js";
import type { OntologyActionParametersTarget, OntologyObjectTarget, OntologyQueryFunctionParametersTarget, OntologyQueryFunctionReturnTarget, OntologyTypeTarget } from "../utils/targets.js";
export type JsonTarget<IR extends OntologyIR> = OntologyTypeTarget<IR> | OntologyObjectTarget<IR> | OntologyActionParametersTarget<IR> | OntologyQueryFunctionParametersTarget<IR> | OntologyQueryFunctionReturnTarget<IR>;
export declare function decode<IR extends OntologyIR>(opts: {
    ir: IR;
    target: JsonTarget<IR>;
    value: unknown;
}): unknown;
export declare function encode<IR extends OntologyIR>(opts: {
    ir: IR;
    target: JsonTarget<IR>;
    value: unknown;
}): unknown;
//# sourceMappingURL=index.d.ts.map