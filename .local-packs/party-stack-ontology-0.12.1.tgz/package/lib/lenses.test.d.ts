export {};
//# sourceMappingURL=lenses.test.d.ts.map