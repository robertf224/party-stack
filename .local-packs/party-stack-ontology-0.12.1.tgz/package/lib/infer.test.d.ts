export {};
//# sourceMappingURL=infer.test.d.ts.map