import type { OntologyPullContext, OntologyPullConfig } from "../OntologyPullConfig.js";
export declare const ONTOLOGY_PULL_CONFIG_PATH = "src/ontology/config.ts";
export declare const ONTOLOGY_IR_PATH = "src/ontology/ontology.ts";
export declare function discoverOntologyPullConfigPath(cwd: string): string | null;
export declare function loadOntologyPullConfig(configPath: string): Promise<OntologyPullConfig>;
export declare function writePulledOntology(config: OntologyPullConfig, outPath: string, context: OntologyPullContext, ontologyImportPath?: string): Promise<void>;
//# sourceMappingURL=pull.d.ts.map