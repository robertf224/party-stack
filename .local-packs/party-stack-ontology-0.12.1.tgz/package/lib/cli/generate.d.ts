#!/usr/bin/env node
export interface GenerateFilesOpts {
    ontology: string;
    outDir: string;
    namespace?: string;
    jsExtensions?: boolean;
}
export declare function generateFiles(options: GenerateFilesOpts): Promise<void>;
//# sourceMappingURL=generate.d.ts.map