import { type LiveOntology } from "../../index.js";
import type { MetaOntology, MetaOntologyContext } from "./types.js";
import type { CreateLiveOntologyOpts } from "../../index.js";
export declare function createMetaLiveOntology(opts: Omit<CreateLiveOntologyOpts<MetaOntologyContext>, "ir">): Promise<LiveOntology<MetaOntology>>;
//# sourceMappingURL=live.d.ts.map