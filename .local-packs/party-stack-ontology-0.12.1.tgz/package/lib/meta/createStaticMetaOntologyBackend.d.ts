import type { OntologyIR } from "../ir/index.js";
import type { OntologyBackendAdapter, OntologyBackendAdapterProvider } from "../live/OntologyBackendAdapter.js";
export interface CreateStaticMetaOntologyBackendAdapterOptions {
    ir: OntologyIR;
    name?: string;
}
/**
 * Creates a read-only meta ontology backend from an existing {@link OntologyIR}.
 *
 * The resulting adapter exposes the same meta collections as the Foundry meta backend
 * (`ObjectType`, `LinkType`, `ValueType`, `ActionType`, `QueryFunctionType`) so local and
 * Foundry deployments can share `createMetaLiveOntology` + `pull()` code paths.
 */
export declare function createStaticMetaOntologyBackendAdapter(opts: CreateStaticMetaOntologyBackendAdapterOptions): OntologyBackendAdapter;
export type CreateStaticMetaOntologyBackendOptions = {
    ir: OntologyIR;
    name?: string;
};
/**
 * Provider form of {@link createStaticMetaOntologyBackendAdapter} for use with
 * `createMetaLiveOntology({ backend })`. The provider IR (meta schema) is ignored;
 * collections are populated from the supplied data IR.
 */
export declare function createStaticMetaOntologyBackend(opts: CreateStaticMetaOntologyBackendOptions): OntologyBackendAdapterProvider;
//# sourceMappingURL=createStaticMetaOntologyBackend.d.ts.map