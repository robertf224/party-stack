import type { OntologyIR } from "../ir/index.js";
import type { OntologyBackendAdapter } from "../live/OntologyBackendAdapter.js";
export declare function createLocalMetaOntologyBackendAdapter(ir: OntologyIR): OntologyBackendAdapter;
//# sourceMappingURL=createLocalMetaOntologyBackendAdapter.d.ts.map