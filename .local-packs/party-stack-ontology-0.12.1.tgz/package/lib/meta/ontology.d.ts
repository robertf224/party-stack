import type { NamedTypeDef } from "../ir/generated/types.js";
declare const _default: {
    linkTypes: {
        id: string;
        source: {
            objectType: string;
            name: string;
            displayName: string;
        };
        target: {
            objectType: string;
            name: string;
            displayName: string;
        };
        foreignKey: string;
        cardinality: "many";
    }[];
    actionTypes: never[];
    queryFunctionTypes: never[];
    types: Array<NamedTypeDef>;
    objectTypes: Array<import("../ir/generated/types.js").ObjectTypeDef>;
};
export default _default;
//# sourceMappingURL=ontology.d.ts.map