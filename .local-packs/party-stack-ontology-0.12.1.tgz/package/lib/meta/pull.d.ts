import type { OntologyIR } from "../ir/generated/types.js";
import type { LiveOntology } from "../live/LiveOntology.js";
import type { MetaOntology } from "./generated/types.js";
export interface PullOptions {
    objectTypeNames: string[];
    actionTypeNames: string[];
    queryFunctionTypeNames: string[];
}
export declare function pull(ontology: LiveOntology<MetaOntology>, options: PullOptions): Promise<OntologyIR>;
//# sourceMappingURL=pull.d.ts.map