export {};
//# sourceMappingURL=createOntologyBackendInstallation.test.d.ts.map