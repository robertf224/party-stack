export {};
//# sourceMappingURL=createMetaOntologyConfiguration.test.d.ts.map