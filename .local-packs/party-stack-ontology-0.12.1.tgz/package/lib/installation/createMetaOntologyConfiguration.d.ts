import type { OntologyConfiguration } from "./types.js";
import type { OntologyIR } from "../ir/index.js";
export type MetaOntologyConfigurationOptions = Omit<OntologyConfiguration, "ir"> | {
    ir: OntologyIR;
};
export declare function createMetaOntologyConfiguration(options: MetaOntologyConfigurationOptions): OntologyConfiguration;
//# sourceMappingURL=createMetaOntologyConfiguration.d.ts.map