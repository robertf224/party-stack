/**
 * Example: Blog ontology with Authors, Posts, and Comments.
 *
 * Demonstrates:
 * - Object types with primary keys and typed properties
 * - Value types (reusable structured types)
 * - Link types with cardinality
 * - Attachment properties (e.g. author avatar)
 * - String enum constraints (e.g. post status)
 * - Optional properties and timestamps
 */
declare const _default: {
    types: {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "line1";
                    readonly displayName: "Line 1";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                }, {
                    readonly name: "line2";
                    readonly displayName: "Line 2";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                }, {
                    readonly name: "city";
                    readonly displayName: "City";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                }, {
                    readonly name: "state";
                    readonly displayName: "State";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                }, {
                    readonly name: "zip";
                    readonly displayName: "ZIP";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                }];
            };
        };
    }[];
    objectTypes: ({
        name: string;
        displayName: string;
        pluralDisplayName: string;
        description: string;
        primaryKey: string;
        properties: ({
            name: string;
            displayName: string;
            type: {
                kind: "string";
                value: {};
            };
            description?: undefined;
        } | {
            name: string;
            displayName: string;
            type: {
                kind: "optional";
                value: {
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                };
            };
            description?: undefined;
        } | {
            name: string;
            displayName: string;
            description: string;
            type: {
                kind: "optional";
                value: {
                    readonly type: {
                        kind: "attachment";
                        value: {};
                    };
                };
            };
        } | {
            name: string;
            displayName: string;
            type: {
                kind: "optional";
                value: {
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "Address";
                        };
                    };
                };
            };
            description?: undefined;
        } | {
            name: string;
            displayName: string;
            type: {
                kind: "timestamp";
                value: {};
            };
            description?: undefined;
        })[];
    } | {
        name: string;
        displayName: string;
        pluralDisplayName: string;
        description: string;
        primaryKey: string;
        properties: ({
            name: string;
            displayName: string;
            type: {
                kind: "string";
                value: {};
            };
        } | {
            name: string;
            displayName: string;
            type: {
                kind: "optional";
                value: {
                    readonly type: {
                        kind: "attachment";
                        value: {};
                    };
                };
            };
        } | {
            name: string;
            displayName: string;
            type: {
                kind: "list";
                value: {
                    readonly elementType: {
                        kind: "string";
                        value: {};
                    };
                };
            };
        } | {
            name: string;
            displayName: string;
            type: {
                kind: "timestamp";
                value: {};
            };
        } | {
            name: string;
            displayName: string;
            type: {
                kind: "optional";
                value: {
                    readonly type: {
                        kind: "timestamp";
                        value: {};
                    };
                };
            };
        })[];
    })[];
    linkTypes: ({
        id: string;
        source: {
            objectType: string;
            name: string;
            displayName: string;
        };
        target: {
            objectType: string;
            name: string;
            displayName: string;
        };
        foreignKey: string;
        cardinality: "many";
    } | {
        id: string;
        source: {
            objectType: string;
            name: string;
            displayName: string;
        };
        target: {
            objectType: string;
            name: string;
            displayName: string;
        };
        foreignKey: string;
        cardinality: "one";
    })[];
    actionTypes: {
        name: string;
        displayName: string;
        description: string;
        parameters: ({
            name: string;
            displayName: string;
            type: {
                kind: "string";
                value: {};
            };
            defaultValue: {
                kind: "functionCall";
                value: {
                    kind: "uuid";
                    value: {};
                };
            };
        } | {
            name: string;
            displayName: string;
            type: {
                kind: "objectReference";
                value: {
                    readonly objectType: "Author";
                };
            };
            defaultValue?: undefined;
        } | {
            name: string;
            displayName: string;
            type: {
                kind: "string";
                value: {};
            };
            defaultValue?: undefined;
        } | {
            name: string;
            displayName: string;
            type: {
                kind: "list";
                value: {
                    readonly elementType: {
                        kind: "string";
                        value: {};
                    };
                };
            };
            defaultValue?: undefined;
        } | {
            name: string;
            displayName: string;
            type: {
                kind: "timestamp";
                value: {};
            };
            defaultValue: {
                kind: "functionCall";
                value: {
                    kind: "now";
                    value: {};
                };
            };
        })[];
        logic: {
            kind: "createObject";
            value: {
                readonly objectType: "Post";
                readonly values: [{
                    readonly property: ["postId"];
                    readonly value: {
                        kind: "valueReference";
                        value: {
                            readonly path: ["postId"];
                        };
                    };
                }, {
                    readonly property: ["title"];
                    readonly value: {
                        kind: "valueReference";
                        value: {
                            readonly path: ["title"];
                        };
                    };
                }, {
                    readonly property: ["body"];
                    readonly value: {
                        kind: "valueReference";
                        value: {
                            readonly path: ["body"];
                        };
                    };
                }, {
                    readonly property: ["authorId"];
                    readonly value: {
                        kind: "valueReference";
                        value: {
                            readonly path: ["author", "authorId"];
                        };
                    };
                }, {
                    readonly property: ["status"];
                    readonly value: {
                        kind: "valueReference";
                        value: {
                            readonly path: ["status"];
                        };
                    };
                }, {
                    readonly property: ["tags"];
                    readonly value: {
                        kind: "valueReference";
                        value: {
                            readonly path: ["tags"];
                        };
                    };
                }, {
                    readonly property: ["createdAt"];
                    readonly value: {
                        kind: "valueReference";
                        value: {
                            readonly path: ["createdAt"];
                        };
                    };
                }];
            };
        }[];
    }[];
    queryFunctionTypes: {
        name: string;
        displayName: string;
        description: string;
        parameters: ({
            name: string;
            displayName: string;
            type: {
                kind: "string";
                value: {};
            };
        } | {
            name: string;
            displayName: string;
            type: {
                kind: "optional";
                value: {
                    readonly type: {
                        kind: "integer";
                        value: {};
                    };
                };
            };
        })[];
        returnType: {
            kind: "list";
            value: {
                readonly elementType: {
                    kind: "objectReference";
                    value: {
                        readonly objectType: "Post";
                    };
                };
            };
        };
    }[];
};
export default _default;
//# sourceMappingURL=blog.d.ts.map