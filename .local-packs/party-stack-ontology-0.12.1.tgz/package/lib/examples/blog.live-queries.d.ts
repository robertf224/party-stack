export declare const postCollection: import("../index.js").OntologyCollection<import("./generated/types.js").Post>;
export declare const authorCollection: import("../index.js").OntologyCollection<import("./generated/types.js").Author>;
export declare const commentCollection: import("../index.js").OntologyCollection<import("./generated/types.js").Comment>;
//# sourceMappingURL=blog.live-queries.d.ts.map