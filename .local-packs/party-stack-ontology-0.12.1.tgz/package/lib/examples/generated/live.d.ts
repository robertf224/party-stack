import { type LiveOntology } from "../../index.js";
import type { BlogOntology } from "./types.js";
import type { CreateLiveOntologyOpts } from "../../index.js";
export declare function createBlogLiveOntology<Context extends Record<string, unknown> = Record<string, unknown>>(opts: Omit<CreateLiveOntologyOpts<Context>, "ir">): Promise<LiveOntology<BlogOntology>>;
//# sourceMappingURL=live.d.ts.map