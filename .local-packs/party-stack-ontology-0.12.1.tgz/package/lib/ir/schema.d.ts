declare const _default: {
    types: ({
        name: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "message";
                    readonly displayName: "Message";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                }];
            };
        };
        description?: undefined;
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "options";
                    readonly displayName: "Options";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "struct";
                                value: {
                                    readonly fields: [{
                                        readonly name: "value";
                                        readonly displayName: "Value";
                                        readonly type: {
                                            kind: "string";
                                            value: {};
                                        };
                                    }, {
                                        readonly name: "label";
                                        readonly displayName: "Label";
                                        readonly type: {
                                            kind: "optional";
                                            value: {
                                                readonly type: {
                                                    kind: "string";
                                                    value: {};
                                                };
                                            };
                                        };
                                    }];
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "regex";
                    readonly displayName: "Regex";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "union";
            value: {
                readonly variants: [{
                    readonly name: "enum";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "StringEnumConstraint";
                        };
                    };
                }, {
                    readonly name: "regex";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "StringRegexConstraint";
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "constraint";
                    readonly displayName: "Constraint";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "ref";
                                value: {
                                    readonly name: "StringConstraint";
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "elementType";
                    readonly displayName: "Element Type";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "TypeDef";
                        };
                    };
                    readonly description: "The type of elements in the list.";
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "keyType";
                    readonly displayName: "Key Type";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "TypeDef";
                        };
                    };
                    readonly description: "The type of keys (must be string right now).";
                }, {
                    readonly name: "valueType";
                    readonly displayName: "Value Type";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "TypeDef";
                        };
                    };
                    readonly description: "The type of values.";
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "name";
                    readonly displayName: "Name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "The field name in code.";
                }, {
                    readonly name: "displayName";
                    readonly displayName: "Display Name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "Human-readable name.";
                }, {
                    readonly name: "type";
                    readonly displayName: "Type";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "TypeDef";
                        };
                    };
                    readonly description: "The field's type.";
                }, {
                    readonly name: "description";
                    readonly displayName: "Description";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                    readonly description: "Optional description.";
                }, {
                    readonly name: "deprecated";
                    readonly displayName: "Deprecated?";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "ref";
                                value: {
                                    readonly name: "Deprecation";
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "fields";
                    readonly displayName: "Fields";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "ref";
                                value: {
                                    readonly name: "FieldDef";
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "name";
                    readonly displayName: "Name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "The variant's discriminator value.";
                }, {
                    readonly name: "type";
                    readonly displayName: "Type";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "TypeDef";
                        };
                    };
                    readonly description: "The variant's payload type.";
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "variants";
                    readonly displayName: "Variants";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "ref";
                                value: {
                                    readonly name: "VariantDef";
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "type";
                    readonly displayName: "Type";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "TypeDef";
                        };
                    };
                    readonly description: "The wrapped type.";
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "okType";
                    readonly displayName: "Ok Type";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "TypeDef";
                        };
                    };
                    readonly description: "The type of the success value.";
                }, {
                    readonly name: "errType";
                    readonly displayName: "Error Type";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "TypeDef";
                        };
                    };
                    readonly description: "The type of the error value.";
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "name";
                    readonly displayName: "Name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "The name of the referenced type.";
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "union";
            value: {
                readonly variants: [{
                    readonly name: "string";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "StringTypeDef";
                        };
                    };
                }, {
                    readonly name: "boolean";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "BooleanTypeDef";
                        };
                    };
                }, {
                    readonly name: "integer";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "IntegerTypeDef";
                        };
                    };
                }, {
                    readonly name: "float";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "FloatTypeDef";
                        };
                    };
                }, {
                    readonly name: "double";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "DoubleTypeDef";
                        };
                    };
                }, {
                    readonly name: "date";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "DateTypeDef";
                        };
                    };
                }, {
                    readonly name: "timestamp";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "TimestampTypeDef";
                        };
                    };
                }, {
                    readonly name: "geopoint";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "GeopointTypeDef";
                        };
                    };
                }, {
                    readonly name: "list";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "ListTypeDef";
                        };
                    };
                }, {
                    readonly name: "map";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "MapTypeDef";
                        };
                    };
                }, {
                    readonly name: "struct";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "StructTypeDef";
                        };
                    };
                }, {
                    readonly name: "union";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "UnionTypeDef";
                        };
                    };
                }, {
                    readonly name: "optional";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "OptionalTypeDef";
                        };
                    };
                }, {
                    readonly name: "result";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "ResultTypeDef";
                        };
                    };
                }, {
                    readonly name: "ref";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "TypeRef";
                        };
                    };
                }, {
                    readonly name: "attachment";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "AttachmentTypeDef";
                        };
                    };
                }, {
                    readonly name: "objectReference";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "ObjectReferenceTypeDef";
                        };
                    };
                }, {
                    readonly name: "unknown";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "UnknownTypeDef";
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "name";
                    readonly displayName: "Name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "The type's name for use in code.";
                }, {
                    readonly name: "description";
                    readonly displayName: "Description";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                    readonly description: "Optional documentation for the type.";
                }, {
                    readonly name: "deprecated";
                    readonly displayName: "Deprecated?";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "ref";
                                value: {
                                    readonly name: "Deprecation";
                                };
                            };
                        };
                    };
                }, {
                    readonly name: "type";
                    readonly displayName: "Type";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "TypeDef";
                        };
                    };
                    readonly description: "The type definition.";
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "string";
            value: {
                readonly constraint: {
                    kind: "enum";
                    value: {
                        readonly options: [{
                            readonly value: "image/bmp";
                            readonly label: "BMP";
                        }, {
                            readonly value: "image/tiff";
                            readonly label: "TIFF";
                        }, {
                            readonly value: "image/nitf";
                            readonly label: "NITF";
                        }, {
                            readonly value: "image/jp2";
                            readonly label: "JPEG 2000";
                        }, {
                            readonly value: "image/jpeg";
                            readonly label: "JPEG";
                        }, {
                            readonly value: "image/png";
                            readonly label: "PNG";
                        }, {
                            readonly value: "image/gif";
                            readonly label: "GIF";
                        }, {
                            readonly value: "image/svg+xml";
                            readonly label: "SVG";
                        }, {
                            readonly value: "image/webp";
                            readonly label: "WebP";
                        }];
                    };
                };
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "width";
                    readonly displayName: "Width";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "struct";
                                value: {
                                    readonly fields: [{
                                        readonly name: "min";
                                        readonly displayName: "Minimum";
                                        readonly type: {
                                            kind: "optional";
                                            value: {
                                                readonly type: {
                                                    kind: "integer";
                                                    value: {};
                                                };
                                            };
                                        };
                                    }, {
                                        readonly name: "max";
                                        readonly displayName: "Maximum";
                                        readonly type: {
                                            kind: "optional";
                                            value: {
                                                readonly type: {
                                                    kind: "integer";
                                                    value: {};
                                                };
                                            };
                                        };
                                    }];
                                };
                            };
                        };
                    };
                }, {
                    readonly name: "height";
                    readonly displayName: "Height";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "struct";
                                value: {
                                    readonly fields: [{
                                        readonly name: "min";
                                        readonly displayName: "Minimum";
                                        readonly type: {
                                            kind: "optional";
                                            value: {
                                                readonly type: {
                                                    kind: "integer";
                                                    value: {};
                                                };
                                            };
                                        };
                                    }, {
                                        readonly name: "max";
                                        readonly displayName: "Maximum";
                                        readonly type: {
                                            kind: "optional";
                                            value: {
                                                readonly type: {
                                                    kind: "integer";
                                                    value: {};
                                                };
                                            };
                                        };
                                    }];
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "mediaTypes";
                    readonly displayName: "Media types";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "list";
                                value: {
                                    readonly elementType: {
                                        kind: "ref";
                                        value: {
                                            readonly name: "ImageMediaType";
                                        };
                                    };
                                };
                            };
                        };
                    };
                }, {
                    readonly name: "dimensions";
                    readonly displayName: "Dimensions";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "ref";
                                value: {
                                    readonly name: "DimensionsConstraint";
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "union";
            value: {
                readonly variants: [{
                    readonly name: "image";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "ImageAttachmentConstraint";
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "size";
                    readonly displayName: "Size";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "struct";
                                value: {
                                    readonly fields: [{
                                        readonly name: "min";
                                        readonly displayName: "Minimum";
                                        readonly type: {
                                            kind: "optional";
                                            value: {
                                                readonly type: {
                                                    kind: "double";
                                                    value: {};
                                                };
                                            };
                                        };
                                    }, {
                                        readonly name: "max";
                                        readonly displayName: "Maximum";
                                        readonly type: {
                                            kind: "optional";
                                            value: {
                                                readonly type: {
                                                    kind: "double";
                                                    value: {};
                                                };
                                            };
                                        };
                                    }];
                                };
                            };
                        };
                    };
                }, {
                    readonly name: "content";
                    readonly displayName: "Content";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "ref";
                                value: {
                                    readonly name: "AttachmentContentConstraint";
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "constraint";
                    readonly displayName: "Constraint";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "ref";
                                value: {
                                    readonly name: "AttachmentConstraint";
                                };
                            };
                        };
                    };
                }, {
                    readonly name: "meta";
                    readonly displayName: "Meta";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "map";
                                value: {
                                    readonly keyType: {
                                        kind: "string";
                                        value: {};
                                    };
                                    readonly valueType: {
                                        kind: "unknown";
                                        value: {};
                                    };
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "objectType";
                    readonly displayName: "Object type";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "The referenced object type name.";
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "name";
                    readonly displayName: "Name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "The property's name.";
                }, {
                    readonly name: "displayName";
                    readonly displayName: "Display name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "Human-readable name.";
                }, {
                    readonly name: "type";
                    readonly displayName: "Type";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "TypeDef";
                        };
                    };
                    readonly description: "The property's type.";
                }, {
                    readonly name: "description";
                    readonly displayName: "Description";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                    readonly description: "Optional description.";
                }, {
                    readonly name: "deprecated";
                    readonly displayName: "Deprecated?";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "ref";
                                value: {
                                    readonly name: "Deprecation";
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "name";
                    readonly displayName: "Name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "The object type's programmatic name.";
                }, {
                    readonly name: "displayName";
                    readonly displayName: "Display name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "Human-readable name.";
                }, {
                    readonly name: "pluralDisplayName";
                    readonly displayName: "Plural display name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                }, {
                    readonly name: "primaryKey";
                    readonly displayName: "Primary key";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "The name of the property that serves as primary key.";
                }, {
                    readonly name: "title";
                    readonly displayName: "Title";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                    readonly description: "The optional property name used as the human-readable title for an object.";
                }, {
                    readonly name: "properties";
                    readonly displayName: "Properties";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "ref";
                                value: {
                                    readonly name: "PropertyDef";
                                };
                            };
                        };
                    };
                    readonly description: "The object type's propertieo.";
                }, {
                    readonly name: "description";
                    readonly displayName: "Description";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                    readonly description: "Optional description.";
                }, {
                    readonly name: "deprecated";
                    readonly displayName: "Deprecated?";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "ref";
                                value: {
                                    readonly name: "Deprecation";
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "objectType";
                    readonly displayName: "Object type";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                }, {
                    readonly name: "name";
                    readonly displayName: "Name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                }, {
                    readonly name: "displayName";
                    readonly displayName: "Display name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                }];
            };
        };
        description?: undefined;
    } | {
        name: string;
        description: string;
        type: {
            kind: "string";
            value: {
                readonly constraint: {
                    kind: "enum";
                    value: {
                        readonly options: [{
                            readonly value: "one";
                            readonly label: "One";
                        }, {
                            readonly value: "many";
                            readonly label: "Many";
                        }];
                    };
                };
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "id";
                    readonly displayName: "ID";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                }, {
                    readonly name: "source";
                    readonly displayName: "Source";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "LinkTypeSideDef";
                        };
                    };
                }, {
                    readonly name: "target";
                    readonly displayName: "Target";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "LinkTypeSideDef";
                        };
                    };
                }, {
                    readonly name: "foreignKey";
                    readonly displayName: "Foreign key";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "The foreign key on the source.";
                }, {
                    readonly name: "cardinality";
                    readonly displayName: "Cardinality";
                    readonly type: {
                        kind: "string";
                        value: {
                            readonly constraint: {
                                kind: "enum";
                                value: {
                                    readonly options: [{
                                        readonly value: "one";
                                        readonly label: "One";
                                    }, {
                                        readonly value: "many";
                                        readonly label: "Many";
                                    }];
                                };
                            };
                        };
                    };
                    readonly description: "How many sources are linked to the target.";
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "fieldPath";
                    readonly displayName: "Field path";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                    readonly description: "The path relative to the action parameter. An empty path targets the parameter.";
                }, {
                    readonly name: "value";
                    readonly displayName: "Value";
                    readonly type: {
                        kind: "unknown";
                        value: {};
                    };
                    readonly description: "The suggested value.";
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "fieldPath";
                    readonly displayName: "Field path";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                    readonly description: "The path relative to the action parameter. An empty path targets the parameter.";
                }, {
                    readonly name: "parameter";
                    readonly displayName: "Parameter";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "The source object-reference action parameter.";
                }, {
                    readonly name: "property";
                    readonly displayName: "Property";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                    readonly description: "The property path on the referenced object.";
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "fieldPath";
                    readonly displayName: "Field path";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                    readonly description: "The path relative to the action parameter. An empty path targets the parameter.";
                }, {
                    readonly name: "objectType";
                    readonly displayName: "Object type";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "The object type returned by the query.";
                }, {
                    readonly name: "objectSet";
                    readonly displayName: "Object set";
                    readonly type: {
                        kind: "unknown";
                        value: {};
                    };
                    readonly description: "The opaque Foundry OMS Actions object-set definition.";
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "union";
            value: {
                readonly variants: [{
                    readonly name: "literal";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "LiteralActionParameterPrefill";
                        };
                    };
                }, {
                    readonly name: "objectProperty";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "ObjectPropertyActionParameterPrefill";
                        };
                    };
                }, {
                    readonly name: "foundryObjectQuery";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "FoundryObjectQueryActionParameterPrefill";
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "name";
                    readonly displayName: "Name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "The parameter's name.";
                }, {
                    readonly name: "displayName";
                    readonly displayName: "Display name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "Human-readable name.";
                }, {
                    readonly name: "type";
                    readonly displayName: "Type";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "TypeDef";
                        };
                    };
                    readonly description: "The parameter's type.";
                }, {
                    readonly name: "description";
                    readonly displayName: "Description";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                    readonly description: "Optional description.";
                }, {
                    readonly name: "deprecated";
                    readonly displayName: "Deprecated?";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "ref";
                                value: {
                                    readonly name: "Deprecation";
                                };
                            };
                        };
                    };
                }, {
                    readonly name: "defaultValue";
                    readonly displayName: "Default value";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "ref";
                                value: {
                                    readonly name: "Expression";
                                };
                            };
                        };
                    };
                    readonly description: "The expression used when the caller does not provide a value.";
                }, {
                    readonly name: "prefills";
                    readonly displayName: "Prefills";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "list";
                                value: {
                                    readonly elementType: {
                                        kind: "ref";
                                        value: {
                                            readonly name: "ActionParameterPrefill";
                                        };
                                    };
                                };
                            };
                        };
                    };
                    readonly description: "Values suggested to users when editing this parameter.";
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "path";
                    readonly displayName: "Path";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "value";
                    readonly displayName: "Value";
                    readonly type: {
                        kind: "unknown";
                        value: {};
                    };
                    readonly description: "The literal value.";
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "union";
            value: {
                readonly variants: [{
                    readonly name: "uuid";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "UuidFunctionCall";
                        };
                    };
                }, {
                    readonly name: "now";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "NowFunctionCall";
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "union";
            value: {
                readonly variants: [{
                    readonly name: "valueReference";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "ValueReferenceExpression";
                        };
                    };
                }, {
                    readonly name: "contextReference";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "ContextReferenceExpression";
                        };
                    };
                }, {
                    readonly name: "functionCall";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "FunctionCallExpression";
                        };
                    };
                }, {
                    readonly name: "literal";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "LiteralExpression";
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "property";
                    readonly displayName: "Property";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                }, {
                    readonly name: "value";
                    readonly displayName: "Value";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "Expression";
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "objectType";
                    readonly displayName: "Object type";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                }, {
                    readonly name: "values";
                    readonly displayName: "Values";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "ref";
                                value: {
                                    readonly name: "PropertyAssignment";
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "object";
                    readonly displayName: "Object";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "ValueReferenceExpression";
                        };
                    };
                }, {
                    readonly name: "values";
                    readonly displayName: "Values";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "ref";
                                value: {
                                    readonly name: "PropertyAssignment";
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "object";
                    readonly displayName: "Object";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "ValueReferenceExpression";
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "union";
            value: {
                readonly variants: [{
                    readonly name: "createObject";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "CreateObjectActionLogicStep";
                        };
                    };
                }, {
                    readonly name: "updateObject";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "UpdateObjectActionLogicStep";
                        };
                    };
                }, {
                    readonly name: "deleteObject";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "DeleteObjectActionLogicStep";
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "name";
                    readonly displayName: "Name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "The object type's programmatic name.";
                }, {
                    readonly name: "displayName";
                    readonly displayName: "Display name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "Human-readable name.";
                }, {
                    readonly name: "parameters";
                    readonly displayName: "Parameters";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "ref";
                                value: {
                                    readonly name: "ActionParameterDef";
                                };
                            };
                        };
                    };
                    readonly description: "The action type's parametero.";
                }, {
                    readonly name: "logic";
                    readonly displayName: "Logic";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "ref";
                                value: {
                                    readonly name: "ActionLogicStep";
                                };
                            };
                        };
                    };
                    readonly description: "The action type's local logic stepo.";
                }, {
                    readonly name: "description";
                    readonly displayName: "Description";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                    readonly description: "Optional description.";
                }, {
                    readonly name: "deprecated";
                    readonly displayName: "Deprecated?";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "ref";
                                value: {
                                    readonly name: "Deprecation";
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "name";
                    readonly displayName: "Name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "The query function parameter's programmatic name.";
                }, {
                    readonly name: "displayName";
                    readonly displayName: "Display name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "Human-readable name.";
                }, {
                    readonly name: "type";
                    readonly displayName: "Type";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "TypeDef";
                        };
                    };
                }, {
                    readonly name: "description";
                    readonly displayName: "Description";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                    readonly description: "Optional description.";
                }, {
                    readonly name: "deprecated";
                    readonly displayName: "Deprecated?";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "ref";
                                value: {
                                    readonly name: "Deprecation";
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "name";
                    readonly displayName: "Name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "The query function type's programmatic name.";
                }, {
                    readonly name: "displayName";
                    readonly displayName: "Display name";
                    readonly type: {
                        kind: "string";
                        value: {};
                    };
                    readonly description: "Human-readable name.";
                }, {
                    readonly name: "parameters";
                    readonly displayName: "Parameters";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "ref";
                                value: {
                                    readonly name: "QueryFunctionParameterDef";
                                };
                            };
                        };
                    };
                    readonly description: "The query function type's parameters.";
                }, {
                    readonly name: "returnType";
                    readonly displayName: "Return type";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "TypeDef";
                        };
                    };
                    readonly description: "The query function type's return type.";
                }, {
                    readonly name: "description";
                    readonly displayName: "Description";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                    readonly description: "Optional description.";
                }, {
                    readonly name: "deprecated";
                    readonly displayName: "Deprecated?";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "ref";
                                value: {
                                    readonly name: "Deprecation";
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "from";
                    readonly displayName: "From";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                }, {
                    readonly name: "to";
                    readonly displayName: "To";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "properties";
                    readonly displayName: "Properties";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "string";
                                value: {};
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "union";
            value: {
                readonly variants: [{
                    readonly name: "move";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "MoveLensOp";
                        };
                    };
                }, {
                    readonly name: "select";
                    readonly type: {
                        kind: "ref";
                        value: {
                            readonly name: "SelectLensOp";
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "operations";
                    readonly displayName: "Operations";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "ref";
                                value: {
                                    readonly name: "LensOp";
                                };
                            };
                        };
                    };
                }];
            };
        };
    } | {
        name: string;
        description: string;
        type: {
            kind: "struct";
            value: {
                readonly fields: [{
                    readonly name: "types";
                    readonly displayName: "Named types";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "ref";
                                value: {
                                    readonly name: "NamedTypeDef";
                                };
                            };
                        };
                    };
                    readonly description: "Named, reusable value types.";
                }, {
                    readonly name: "objectTypes";
                    readonly displayName: "Object types";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "ref";
                                value: {
                                    readonly name: "ObjectTypeDef";
                                };
                            };
                        };
                    };
                    readonly description: "Object type definitions.";
                }, {
                    readonly name: "linkTypes";
                    readonly displayName: "Link types";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "ref";
                                value: {
                                    readonly name: "LinkTypeDef";
                                };
                            };
                        };
                    };
                    readonly description: "Relationship definitions between object types.";
                }, {
                    readonly name: "actionTypes";
                    readonly displayName: "Action types";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "ref";
                                value: {
                                    readonly name: "ActionTypeDef";
                                };
                            };
                        };
                    };
                    readonly description: "Action type definitions.";
                }, {
                    readonly name: "queryFunctionTypes";
                    readonly displayName: "Query function types";
                    readonly type: {
                        kind: "list";
                        value: {
                            readonly elementType: {
                                kind: "ref";
                                value: {
                                    readonly name: "QueryFunctionTypeDef";
                                };
                            };
                        };
                    };
                    readonly description: "Query function type definitions.";
                }, {
                    readonly name: "contextType";
                    readonly displayName: "Context type";
                    readonly type: {
                        kind: "optional";
                        value: {
                            readonly type: {
                                kind: "ref";
                                value: {
                                    readonly name: "TypeDef";
                                };
                            };
                        };
                    };
                    readonly description: "Optional typed execution context available to ontology expressions.";
                }];
            };
        };
    })[];
    objectTypes: never[];
    linkTypes: never[];
    actionTypes: never[];
    queryFunctionTypes: never[];
};
export default _default;
//# sourceMappingURL=schema.d.ts.map