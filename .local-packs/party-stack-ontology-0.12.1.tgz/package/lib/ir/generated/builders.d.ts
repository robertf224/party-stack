import * as t from "./types.js";
export declare const string: <const Value extends Extract<t.TypeDef, {
    kind: "string";
}>["value"]>(value: Value) => {
    kind: "string";
    value: Value;
};
export declare const boolean: <const Value extends Extract<t.TypeDef, {
    kind: "boolean";
}>["value"]>(value: Value) => {
    kind: "boolean";
    value: Value;
};
export declare const integer: <const Value extends Extract<t.TypeDef, {
    kind: "integer";
}>["value"]>(value: Value) => {
    kind: "integer";
    value: Value;
};
export declare const float: <const Value extends Extract<t.TypeDef, {
    kind: "float";
}>["value"]>(value: Value) => {
    kind: "float";
    value: Value;
};
export declare const double: <const Value extends Extract<t.TypeDef, {
    kind: "double";
}>["value"]>(value: Value) => {
    kind: "double";
    value: Value;
};
export declare const date: <const Value extends Extract<t.TypeDef, {
    kind: "date";
}>["value"]>(value: Value) => {
    kind: "date";
    value: Value;
};
export declare const timestamp: <const Value extends Extract<t.TypeDef, {
    kind: "timestamp";
}>["value"]>(value: Value) => {
    kind: "timestamp";
    value: Value;
};
export declare const geopoint: <const Value extends Extract<t.TypeDef, {
    kind: "geopoint";
}>["value"]>(value: Value) => {
    kind: "geopoint";
    value: Value;
};
export declare const list: <const Value extends Extract<t.TypeDef, {
    kind: "list";
}>["value"]>(value: Value) => {
    kind: "list";
    value: Value;
};
export declare const map: <const Value extends Extract<t.TypeDef, {
    kind: "map";
}>["value"]>(value: Value) => {
    kind: "map";
    value: Value;
};
export declare const struct: <const Value extends Extract<t.TypeDef, {
    kind: "struct";
}>["value"]>(value: Value) => {
    kind: "struct";
    value: Value;
};
export declare const union: <const Value extends Extract<t.TypeDef, {
    kind: "union";
}>["value"]>(value: Value) => {
    kind: "union";
    value: Value;
};
export declare const optional: <const Value extends Extract<t.TypeDef, {
    kind: "optional";
}>["value"]>(value: Value) => {
    kind: "optional";
    value: Value;
};
export declare const result: <const Value extends Extract<t.TypeDef, {
    kind: "result";
}>["value"]>(value: Value) => {
    kind: "result";
    value: Value;
};
export declare const ref: <const Value extends Extract<t.TypeDef, {
    kind: "ref";
}>["value"]>(value: Value) => {
    kind: "ref";
    value: Value;
};
export declare const attachment: <const Value extends Extract<t.TypeDef, {
    kind: "attachment";
}>["value"]>(value: Value) => {
    kind: "attachment";
    value: Value;
};
export declare const objectReference: <const Value extends Extract<t.TypeDef, {
    kind: "objectReference";
}>["value"]>(value: Value) => {
    kind: "objectReference";
    value: Value;
};
export declare const unknown: <const Value extends Extract<t.TypeDef, {
    kind: "unknown";
}>["value"]>(value: Value) => {
    kind: "unknown";
    value: Value;
};
export declare const StringConstraint: {
    enum: <const Value extends Extract<t.StringConstraint, {
        kind: "enum";
    }>["value"]>(value: Value) => {
        kind: "enum";
        value: Value;
    };
    regex: <const Value extends Extract<t.StringConstraint, {
        kind: "regex";
    }>["value"]>(value: Value) => {
        kind: "regex";
        value: Value;
    };
};
export declare const AttachmentContentConstraint: {
    image: <const Value extends Extract<t.AttachmentContentConstraint, {
        kind: "image";
    }>["value"]>(value: Value) => {
        kind: "image";
        value: Value;
    };
};
export declare const ActionParameterPrefill: {
    literal: <const Value extends Extract<t.ActionParameterPrefill, {
        kind: "literal";
    }>["value"]>(value: Value) => {
        kind: "literal";
        value: Value;
    };
    objectProperty: <const Value extends Extract<t.ActionParameterPrefill, {
        kind: "objectProperty";
    }>["value"]>(value: Value) => {
        kind: "objectProperty";
        value: Value;
    };
    foundryObjectQuery: <const Value extends Extract<t.ActionParameterPrefill, {
        kind: "foundryObjectQuery";
    }>["value"]>(value: Value) => {
        kind: "foundryObjectQuery";
        value: Value;
    };
};
export declare const FunctionCallExpression: {
    uuid: <const Value extends Extract<t.FunctionCallExpression, {
        kind: "uuid";
    }>["value"]>(value: Value) => {
        kind: "uuid";
        value: Value;
    };
    now: <const Value extends Extract<t.FunctionCallExpression, {
        kind: "now";
    }>["value"]>(value: Value) => {
        kind: "now";
        value: Value;
    };
};
export declare const Expression: {
    valueReference: <const Value extends Extract<t.Expression, {
        kind: "valueReference";
    }>["value"]>(value: Value) => {
        kind: "valueReference";
        value: Value;
    };
    contextReference: <const Value extends Extract<t.Expression, {
        kind: "contextReference";
    }>["value"]>(value: Value) => {
        kind: "contextReference";
        value: Value;
    };
    functionCall: <const Value extends Extract<t.Expression, {
        kind: "functionCall";
    }>["value"]>(value: Value) => {
        kind: "functionCall";
        value: Value;
    };
    literal: <const Value extends Extract<t.Expression, {
        kind: "literal";
    }>["value"]>(value: Value) => {
        kind: "literal";
        value: Value;
    };
};
export declare const ActionLogicStep: {
    createObject: <const Value extends Extract<t.ActionLogicStep, {
        kind: "createObject";
    }>["value"]>(value: Value) => {
        kind: "createObject";
        value: Value;
    };
    updateObject: <const Value extends Extract<t.ActionLogicStep, {
        kind: "updateObject";
    }>["value"]>(value: Value) => {
        kind: "updateObject";
        value: Value;
    };
    deleteObject: <const Value extends Extract<t.ActionLogicStep, {
        kind: "deleteObject";
    }>["value"]>(value: Value) => {
        kind: "deleteObject";
        value: Value;
    };
};
export declare const LensOp: {
    move: <const Value extends Extract<t.LensOp, {
        kind: "move";
    }>["value"]>(value: Value) => {
        kind: "move";
        value: Value;
    };
    select: <const Value extends Extract<t.LensOp, {
        kind: "select";
    }>["value"]>(value: Value) => {
        kind: "select";
        value: Value;
    };
};
export declare const o: {
    string: <const Value extends Extract<t.TypeDef, {
        kind: "string";
    }>["value"]>(value: Value) => {
        kind: "string";
        value: Value;
    };
    boolean: <const Value extends Extract<t.TypeDef, {
        kind: "boolean";
    }>["value"]>(value: Value) => {
        kind: "boolean";
        value: Value;
    };
    integer: <const Value extends Extract<t.TypeDef, {
        kind: "integer";
    }>["value"]>(value: Value) => {
        kind: "integer";
        value: Value;
    };
    float: <const Value extends Extract<t.TypeDef, {
        kind: "float";
    }>["value"]>(value: Value) => {
        kind: "float";
        value: Value;
    };
    double: <const Value extends Extract<t.TypeDef, {
        kind: "double";
    }>["value"]>(value: Value) => {
        kind: "double";
        value: Value;
    };
    date: <const Value extends Extract<t.TypeDef, {
        kind: "date";
    }>["value"]>(value: Value) => {
        kind: "date";
        value: Value;
    };
    timestamp: <const Value extends Extract<t.TypeDef, {
        kind: "timestamp";
    }>["value"]>(value: Value) => {
        kind: "timestamp";
        value: Value;
    };
    geopoint: <const Value extends Extract<t.TypeDef, {
        kind: "geopoint";
    }>["value"]>(value: Value) => {
        kind: "geopoint";
        value: Value;
    };
    list: <const Value extends Extract<t.TypeDef, {
        kind: "list";
    }>["value"]>(value: Value) => {
        kind: "list";
        value: Value;
    };
    map: <const Value extends Extract<t.TypeDef, {
        kind: "map";
    }>["value"]>(value: Value) => {
        kind: "map";
        value: Value;
    };
    struct: <const Value extends Extract<t.TypeDef, {
        kind: "struct";
    }>["value"]>(value: Value) => {
        kind: "struct";
        value: Value;
    };
    union: <const Value extends Extract<t.TypeDef, {
        kind: "union";
    }>["value"]>(value: Value) => {
        kind: "union";
        value: Value;
    };
    optional: <const Value extends Extract<t.TypeDef, {
        kind: "optional";
    }>["value"]>(value: Value) => {
        kind: "optional";
        value: Value;
    };
    result: <const Value extends Extract<t.TypeDef, {
        kind: "result";
    }>["value"]>(value: Value) => {
        kind: "result";
        value: Value;
    };
    ref: <const Value extends Extract<t.TypeDef, {
        kind: "ref";
    }>["value"]>(value: Value) => {
        kind: "ref";
        value: Value;
    };
    attachment: <const Value extends Extract<t.TypeDef, {
        kind: "attachment";
    }>["value"]>(value: Value) => {
        kind: "attachment";
        value: Value;
    };
    objectReference: <const Value extends Extract<t.TypeDef, {
        kind: "objectReference";
    }>["value"]>(value: Value) => {
        kind: "objectReference";
        value: Value;
    };
    unknown: <const Value extends Extract<t.TypeDef, {
        kind: "unknown";
    }>["value"]>(value: Value) => {
        kind: "unknown";
        value: Value;
    };
    StringConstraint: {
        enum: <const Value extends Extract<t.StringConstraint, {
            kind: "enum";
        }>["value"]>(value: Value) => {
            kind: "enum";
            value: Value;
        };
        regex: <const Value extends Extract<t.StringConstraint, {
            kind: "regex";
        }>["value"]>(value: Value) => {
            kind: "regex";
            value: Value;
        };
    };
    AttachmentContentConstraint: {
        image: <const Value extends Extract<t.AttachmentContentConstraint, {
            kind: "image";
        }>["value"]>(value: Value) => {
            kind: "image";
            value: Value;
        };
    };
    ActionParameterPrefill: {
        literal: <const Value extends Extract<t.ActionParameterPrefill, {
            kind: "literal";
        }>["value"]>(value: Value) => {
            kind: "literal";
            value: Value;
        };
        objectProperty: <const Value extends Extract<t.ActionParameterPrefill, {
            kind: "objectProperty";
        }>["value"]>(value: Value) => {
            kind: "objectProperty";
            value: Value;
        };
        foundryObjectQuery: <const Value extends Extract<t.ActionParameterPrefill, {
            kind: "foundryObjectQuery";
        }>["value"]>(value: Value) => {
            kind: "foundryObjectQuery";
            value: Value;
        };
    };
    FunctionCallExpression: {
        uuid: <const Value extends Extract<t.FunctionCallExpression, {
            kind: "uuid";
        }>["value"]>(value: Value) => {
            kind: "uuid";
            value: Value;
        };
        now: <const Value extends Extract<t.FunctionCallExpression, {
            kind: "now";
        }>["value"]>(value: Value) => {
            kind: "now";
            value: Value;
        };
    };
    Expression: {
        valueReference: <const Value extends Extract<t.Expression, {
            kind: "valueReference";
        }>["value"]>(value: Value) => {
            kind: "valueReference";
            value: Value;
        };
        contextReference: <const Value extends Extract<t.Expression, {
            kind: "contextReference";
        }>["value"]>(value: Value) => {
            kind: "contextReference";
            value: Value;
        };
        functionCall: <const Value extends Extract<t.Expression, {
            kind: "functionCall";
        }>["value"]>(value: Value) => {
            kind: "functionCall";
            value: Value;
        };
        literal: <const Value extends Extract<t.Expression, {
            kind: "literal";
        }>["value"]>(value: Value) => {
            kind: "literal";
            value: Value;
        };
    };
    ActionLogicStep: {
        createObject: <const Value extends Extract<t.ActionLogicStep, {
            kind: "createObject";
        }>["value"]>(value: Value) => {
            kind: "createObject";
            value: Value;
        };
        updateObject: <const Value extends Extract<t.ActionLogicStep, {
            kind: "updateObject";
        }>["value"]>(value: Value) => {
            kind: "updateObject";
            value: Value;
        };
        deleteObject: <const Value extends Extract<t.ActionLogicStep, {
            kind: "deleteObject";
        }>["value"]>(value: Value) => {
            kind: "deleteObject";
            value: Value;
        };
    };
    LensOp: {
        move: <const Value extends Extract<t.LensOp, {
            kind: "move";
        }>["value"]>(value: Value) => {
            kind: "move";
            value: Value;
        };
        select: <const Value extends Extract<t.LensOp, {
            kind: "select";
        }>["value"]>(value: Value) => {
            kind: "select";
            value: Value;
        };
    };
};
//# sourceMappingURL=builders.d.ts.map