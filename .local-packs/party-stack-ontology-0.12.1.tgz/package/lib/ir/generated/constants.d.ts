export declare const ImageMediaTypeOptions: readonly [{
    readonly value: "image/bmp";
    readonly label: "BMP";
}, {
    readonly value: "image/tiff";
    readonly label: "TIFF";
}, {
    readonly value: "image/nitf";
    readonly label: "NITF";
}, {
    readonly value: "image/jp2";
    readonly label: "JPEG 2000";
}, {
    readonly value: "image/jpeg";
    readonly label: "JPEG";
}, {
    readonly value: "image/png";
    readonly label: "PNG";
}, {
    readonly value: "image/gif";
    readonly label: "GIF";
}, {
    readonly value: "image/svg+xml";
    readonly label: "SVG";
}, {
    readonly value: "image/webp";
    readonly label: "WebP";
}];
export declare const LinkCardinalityOptions: readonly [{
    readonly value: "one";
    readonly label: "One";
}, {
    readonly value: "many";
    readonly label: "Many";
}];
//# sourceMappingURL=constants.d.ts.map