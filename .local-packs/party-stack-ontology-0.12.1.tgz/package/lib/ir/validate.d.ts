import type { OntologyIR } from "./generated/types.js";
export type ValidationPathElement = string | number;
export interface ValidationError {
    path: ValidationPathElement[];
    message: string;
}
export type ValidationResult = {
    kind: "ok";
} | {
    kind: "err";
    errors: ValidationError[];
};
export declare function validate(ontology: OntologyIR): ValidationResult;
//# sourceMappingURL=validate.d.ts.map