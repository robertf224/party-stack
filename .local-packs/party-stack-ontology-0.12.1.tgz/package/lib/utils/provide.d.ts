export declare function provide<Args extends unknown[], T extends object>(provider: T | ((...args: Args) => T | Promise<T>), ...args: Args): Promise<T>;
//# sourceMappingURL=provide.d.ts.map