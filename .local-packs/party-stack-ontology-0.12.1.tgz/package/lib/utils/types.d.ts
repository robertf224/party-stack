import type { OntologyAttachmentCreateTarget } from "./targets.js";
import type { OntologyIR, TypeDef } from "../ir/generated/types.js";
export declare function unwrapType(type: TypeDef): {
    type: TypeDef;
    isOptional: boolean;
};
export declare function resolveType(ir: OntologyIR, type: TypeDef): TypeDef;
export declare function unwrapValueType(ir: OntologyIR, type: TypeDef): TypeDef;
export declare function getTargetValueType(ir: OntologyIR, target: OntologyAttachmentCreateTarget): TypeDef;
//# sourceMappingURL=types.d.ts.map