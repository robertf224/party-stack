import { z } from "zod";
export type RemoteOntologyErrorCode = "FORBIDDEN" | "VALIDATION" | "NOT_FOUND" | "BAD_REQUEST" | "BACKEND" | "INTERNAL";
export interface RemoteOntologyErrorDetails {
    parameters?: Record<string, unknown>;
    validation?: unknown;
    [key: string]: unknown;
}
export interface RemoteOntologyErrorEnvelope {
    v: 1;
    name: string;
    code: RemoteOntologyErrorCode;
    status: number;
    message: string;
    retryable: boolean;
    details?: RemoteOntologyErrorDetails;
}
export declare const remoteOntologyErrorEnvelopeSchema: z.ZodObject<{
    v: z.ZodLiteral<1>;
    name: z.ZodString;
    code: z.ZodEnum<{
        BAD_REQUEST: "BAD_REQUEST";
        FORBIDDEN: "FORBIDDEN";
        NOT_FOUND: "NOT_FOUND";
        VALIDATION: "VALIDATION";
        INTERNAL: "INTERNAL";
        BACKEND: "BACKEND";
    }>;
    status: z.ZodNumber;
    message: z.ZodString;
    retryable: z.ZodBoolean;
    details: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
}, z.core.$strict>;
export declare class RemoteOntologyError extends Error {
    readonly code: RemoteOntologyErrorCode;
    readonly status: number;
    readonly retryable: boolean;
    readonly details?: RemoteOntologyErrorDetails;
    constructor(opts: {
        name?: string;
        code: RemoteOntologyErrorCode;
        status: number;
        message: string;
        retryable?: boolean;
        details?: RemoteOntologyErrorDetails;
        cause?: unknown;
    });
    toJSON(): RemoteOntologyErrorEnvelope;
    static fromEnvelope(envelope: RemoteOntologyErrorEnvelope): RemoteOntologyError;
}
export declare function isRemoteOntologyErrorEnvelope(value: unknown): value is RemoteOntologyErrorEnvelope;
export declare function parseRemoteOntologyErrorBody(text: string, status: number): RemoteOntologyError;
export declare function statusToCode(status: number): RemoteOntologyErrorCode;
export declare function remoteOntologyErrorFromUnknown(error: unknown): RemoteOntologyError;
//# sourceMappingURL=errors.d.ts.map