import { z } from "zod";
import type { LoadSubsetOptions } from "@tanstack/db";
import type { OntologyAttachmentIdMapping, OntologyAttachmentUpload, OntologyIR, PartialAttachmentMetadata } from "@party-stack/ontology";
import type { attachment } from "@party-stack/ontology/values";
export interface RemoteOntologyDescription {
    ir: OntologyIR;
    context?: Record<string, unknown>;
}
export type RemoteOntologyEndpoint = "describe" | "load-subset" | "apply-action" | "run-query-function" | "attachment-metadata" | "attachment-content";
export type RemoteDescribeRequest = Record<string, never>;
export type RemoteLoadSubsetOptions = Omit<LoadSubsetOptions, "subscription">;
export interface RemoteLoadSubsetRequest {
    objectType: string;
    options?: RemoteLoadSubsetOptions;
}
export interface RemoteLoadSubsetResponse {
    objectType: string;
    objects: Record<string, unknown>[];
}
export interface RemoteApplyActionRequest {
    actionType: string;
    parameters: Record<string, unknown>;
    idempotencyKey?: string;
}
export interface RemoteApplyActionResponse {
    invalidatedObjectTypes?: string[];
    attachmentIdMappings?: OntologyAttachmentIdMapping[];
}
export interface RemoteRunQueryFunctionRequest {
    queryFunctionType: string;
    parameters: Record<string, unknown>;
}
export interface RemoteRunQueryFunctionResponse {
    value: unknown;
}
export interface RemoteAttachmentRequest {
    attachment: attachment;
}
export interface RemoteAttachmentMetadataRequest extends RemoteAttachmentRequest {
    selection: ReadonlyArray<keyof PartialAttachmentMetadata>;
}
export interface RemoteOntologyTransportOptions {
    signal?: AbortSignal;
    attachments?: OntologyAttachmentUpload[];
}
export interface RemoteOntologyTransport {
    describe: (options?: RemoteOntologyTransportOptions) => Promise<RemoteOntologyDescription>;
    loadSubset: (request: RemoteLoadSubsetRequest, options?: RemoteOntologyTransportOptions) => Promise<RemoteLoadSubsetResponse>;
    applyAction: (request: RemoteApplyActionRequest, options?: RemoteOntologyTransportOptions) => Promise<RemoteApplyActionResponse>;
    runQueryFunction: (request: RemoteRunQueryFunctionRequest, options?: RemoteOntologyTransportOptions) => Promise<RemoteRunQueryFunctionResponse>;
    getAttachmentMetadata: (request: RemoteAttachmentMetadataRequest, options?: RemoteOntologyTransportOptions) => Promise<PartialAttachmentMetadata>;
    getAttachmentContent: (request: RemoteAttachmentRequest, options?: RemoteOntologyTransportOptions) => Promise<Blob>;
}
export type RemoteOntologyRequestByEndpoint = {
    describe: RemoteDescribeRequest;
    "load-subset": RemoteLoadSubsetRequest;
    "apply-action": RemoteApplyActionRequest;
    "run-query-function": RemoteRunQueryFunctionRequest;
    "attachment-metadata": RemoteAttachmentMetadataRequest;
    "attachment-content": RemoteAttachmentRequest;
};
export type RemoteOntologyResponseByEndpoint = {
    describe: RemoteOntologyDescription;
    "load-subset": RemoteLoadSubsetResponse;
    "apply-action": RemoteApplyActionResponse;
    "run-query-function": RemoteRunQueryFunctionResponse;
    "attachment-metadata": PartialAttachmentMetadata;
    "attachment-content": Blob;
};
export type RemoteOntologyRequestEnvelope = {
    endpoint: "describe";
    input: RemoteDescribeRequest;
} | {
    endpoint: "load-subset";
    input: RemoteLoadSubsetRequest;
} | {
    endpoint: "apply-action";
    input: RemoteApplyActionRequest;
} | {
    endpoint: "run-query-function";
    input: RemoteRunQueryFunctionRequest;
} | {
    endpoint: "attachment-metadata";
    input: RemoteAttachmentMetadataRequest;
} | {
    endpoint: "attachment-content";
    input: RemoteAttachmentRequest;
};
export declare function serializeRemoteOntologyJson(value: unknown): string;
export declare function parseRemoteOntologyJson(text: string): unknown;
export declare const remoteOntologyEndpointSchema: z.ZodEnum<{
    describe: "describe";
    "load-subset": "load-subset";
    "apply-action": "apply-action";
    "run-query-function": "run-query-function";
    "attachment-metadata": "attachment-metadata";
    "attachment-content": "attachment-content";
}>;
export declare const remoteLoadSubsetOptionsSchema: z.ZodType<RemoteLoadSubsetOptions>;
export declare const remoteDescribeRequestSchema: z.ZodObject<{}, z.core.$strict>;
export declare const remoteLoadSubsetRequestSchema: z.ZodObject<{
    objectType: z.ZodString;
    options: z.ZodOptional<z.ZodType<RemoteLoadSubsetOptions, unknown, z.core.$ZodTypeInternals<RemoteLoadSubsetOptions, unknown>>>;
}, z.core.$strict>;
export declare const remoteApplyActionRequestSchema: z.ZodObject<{
    actionType: z.ZodString;
    parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    idempotencyKey: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const remoteRunQueryFunctionRequestSchema: z.ZodObject<{
    queryFunctionType: z.ZodString;
    parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
}, z.core.$strict>;
export declare const remoteAttachmentSchema: z.ZodObject<{
    id: z.ZodString;
    type: z.ZodOptional<z.ZodString>;
    source: z.ZodOptional<z.ZodObject<{
        objectType: z.ZodString;
        primaryKey: z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>;
        property: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const remoteAttachmentRequestSchema: z.ZodObject<{
    attachment: z.ZodObject<{
        id: z.ZodString;
        type: z.ZodOptional<z.ZodString>;
        source: z.ZodOptional<z.ZodObject<{
            objectType: z.ZodString;
            primaryKey: z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>;
            property: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const remoteAttachmentMetadataRequestSchema: z.ZodObject<{
    attachment: z.ZodObject<{
        id: z.ZodString;
        type: z.ZodOptional<z.ZodString>;
        source: z.ZodOptional<z.ZodObject<{
            objectType: z.ZodString;
            primaryKey: z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>;
            property: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    selection: z.ZodArray<z.ZodEnum<{
        type: "type";
        name: "name";
        size: "size";
        dimensions: "dimensions";
    }>>;
}, z.core.$strict>;
export declare function parseRemoteOntologyRequest(endpoint: RemoteOntologyEndpoint, input: unknown): RemoteOntologyRequestEnvelope;
export declare function serializeLoadSubsetOptions(options: LoadSubsetOptions | undefined): RemoteLoadSubsetOptions;
//# sourceMappingURL=protocol.d.ts.map