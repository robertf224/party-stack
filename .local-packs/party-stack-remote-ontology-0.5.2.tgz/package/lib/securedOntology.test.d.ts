export {};
//# sourceMappingURL=securedOntology.test.d.ts.map