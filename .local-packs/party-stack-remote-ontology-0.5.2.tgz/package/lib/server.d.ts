import { type Collection, type InitialQueryBuilder, type QueryBuilder, type Context as QueryBuilderContext } from "@tanstack/db";
import type { LiveOntology, OntologyBackendAdapter, OntologyDefinition, OntologyIR } from "@party-stack/ontology";
import { type FixedActionParameterValues } from "./securedOntology.js";
import type { RemoteLoadSubsetRequest } from "./protocol.js";
type ObjectTypeName<Ontology extends OntologyDefinition> = Extract<keyof Ontology["objectTypes"], string>;
type ObjectTypeObject<Ontology extends OntologyDefinition, ObjectType extends ObjectTypeName<Ontology>> = Ontology["objectTypes"][ObjectType];
type KnownStringKeys<T> = Extract<{
    [Key in keyof T]: string extends Key ? never : Key;
}[keyof T], string>;
type ObjectTypePropertyName<Ontology extends OntologyDefinition, ObjectType extends ObjectTypeName<Ontology>> = KnownStringKeys<ObjectTypeObject<Ontology, ObjectType>>;
export type RemoteOntologyLoadSubsetQuery<TObject extends Record<string, unknown>> = QueryBuilder<QueryBuilderContext & {
    baseSchema: {
        object: TObject;
    };
    schema: {
        object: TObject;
    };
    fromSourceName: "object";
}>;
export type RemoteOntologyBaseObjectTypeQueries<Context, Ontology extends OntologyDefinition> = {
    [ObjectType in ObjectTypeName<Ontology>]?: (args: {
        ctx: Context;
        objectType: ObjectType;
        request: RemoteLoadSubsetRequest & {
            objectType: ObjectType;
        };
        q: InitialQueryBuilder;
        collection: Collection<ObjectTypeObject<Ontology, ObjectType>>;
    }) => RemoteOntologyLoadSubsetQuery<ObjectTypeObject<Ontology, ObjectType>>;
};
type RemoteOntologyAllowedObjectTypePropertyList<Context, Ontology extends OntologyDefinition, ObjectType extends ObjectTypeName<Ontology>> = readonly ObjectTypePropertyName<Ontology, ObjectType>[] | ((args: {
    ctx: Context;
    objectType: ObjectType;
    request: RemoteLoadSubsetRequest & {
        objectType: ObjectType;
    };
}) => readonly ObjectTypePropertyName<Ontology, ObjectType>[]);
export type RemoteOntologyAllowedObjectTypeProperties<Context, Ontology extends OntologyDefinition> = {
    [ObjectType in ObjectTypeName<Ontology>]?: RemoteOntologyAllowedObjectTypePropertyList<Context, Ontology, ObjectType>;
};
export type RemoteOntologyClientContextPolicy<Context> = "forward" | ((ctx: Context) => Record<string, unknown> | undefined | Promise<Record<string, unknown> | undefined>);
export type RemoteOntologyApplyActionRequest<Ontology extends OntologyDefinition = OntologyDefinition> = {
    [ActionTypeName in Extract<keyof Ontology["actionTypes"], string>]: {
        actionType: ActionTypeName;
        parameters: Ontology["actionTypes"][ActionTypeName]["parameters"];
    };
}[Extract<keyof Ontology["actionTypes"], string>];
export type RemoteOntologyRunQueryFunctionRequest<Ontology extends OntologyDefinition = OntologyDefinition> = {
    [QueryFunctionTypeName in Extract<keyof Ontology["queryFunctionTypes"], string>]: {
        queryFunctionType: QueryFunctionTypeName;
        parameters: Ontology["queryFunctionTypes"][QueryFunctionTypeName]["parameters"];
    };
}[Extract<keyof Ontology["queryFunctionTypes"], string>];
export interface RemoteOntologyPolicy<Context, Ontology extends OntologyDefinition = OntologyDefinition> {
    baseObjectTypeQueries?: RemoteOntologyBaseObjectTypeQueries<Context, Ontology>;
    allowedObjectTypeProperties?: RemoteOntologyAllowedObjectTypeProperties<Context, Ontology>;
    fixedActionParameterValues?: FixedActionParameterValues<Ontology>;
    clientContext?: RemoteOntologyClientContextPolicy<Context>;
    /**
     * Optional action-type visibility for describe. Defaults to all action types.
     */
    visibleActionTypes?: readonly string[] | "all" | ((ctx: Context) => readonly string[] | "all" | Promise<readonly string[] | "all">);
    /**
     * Optional query-function visibility for describe. Defaults to all query functions.
     */
    visibleQueryFunctionTypes?: readonly string[] | "all" | ((ctx: Context) => readonly string[] | "all" | Promise<readonly string[] | "all">);
    canApplyAction?: (ctx: Context, request: RemoteOntologyApplyActionRequest<Ontology>, opts: RemoteOntologyCanApplyActionOptions<Ontology>) => boolean | Promise<boolean>;
    canRunQueryFunction?: (ctx: Context, request: RemoteOntologyRunQueryFunctionRequest<Ontology>, opts: RemoteOntologyCanRunQueryOptions<Ontology>) => boolean | Promise<boolean>;
}
export interface CreateRemoteOntologyServerOptions<Context = Record<string, unknown>, Ontology extends OntologyDefinition = OntologyDefinition> {
    ir: OntologyIR | ((ctx: Context) => OntologyIR | Promise<OntologyIR>);
    backendAdapter: OntologyBackendAdapter | ((ctx: Context) => OntologyBackendAdapter | Promise<OntologyBackendAdapter>);
    getContext?: (request: Request) => Context | Promise<Context>;
    policy?: RemoteOntologyPolicy<Context, Ontology>;
}
export interface RemoteOntologyServer {
    handleRequest: (request: Request) => Promise<Response>;
}
export interface RemoteOntologyCanApplyActionOptions<Ontology extends OntologyDefinition = OntologyDefinition> {
    objects: LiveOntology<Ontology>["objects"];
}
export interface RemoteOntologyCanRunQueryOptions<Ontology extends OntologyDefinition = OntologyDefinition> {
    objects: LiveOntology<Ontology>["objects"];
}
export declare function createRemoteOntologyServer<Context = Record<string, unknown>, Ontology extends OntologyDefinition = OntologyDefinition>(opts: CreateRemoteOntologyServerOptions<Context, Ontology>): RemoteOntologyServer;
export {};
//# sourceMappingURL=server.d.ts.map