import type { RemoteOntologyTransport } from "./protocol.js";
import type { OntologyIR } from "@party-stack/ontology";
export interface HttpRemoteOntologyTransportOptions {
    url: string | URL;
    ir?: OntologyIR;
    fetch?: typeof fetch;
    headers?: HeadersInit | (() => HeadersInit);
}
export declare function createHttpRemoteOntologyTransport(opts: HttpRemoteOntologyTransportOptions): RemoteOntologyTransport;
//# sourceMappingURL=http.d.ts.map