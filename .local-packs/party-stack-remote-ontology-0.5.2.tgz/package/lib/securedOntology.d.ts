import type { Expression, OntologyDefinition, OntologyIR } from "@party-stack/ontology";
export type FixedActionParameterValue = Expression;
export type FixedActionParameterValues<Ontology extends OntologyDefinition = OntologyDefinition> = {
    [ActionTypeName in Extract<keyof Ontology["actionTypes"], string>]?: {
        [ParameterName in Extract<keyof Ontology["actionTypes"][ActionTypeName]["parameters"], string>]?: FixedActionParameterValue;
    };
};
export type ClientContextProjectionMode = "none" | "forward" | "projected";
export declare function projectRemoteOntologyIR<Context, Ontology extends OntologyDefinition = OntologyDefinition>(opts: {
    ir: OntologyIR;
    serverContext: Context;
    clientContext?: Record<string, unknown>;
    clientContextMode?: ClientContextProjectionMode;
    fixedActionParameterValues?: FixedActionParameterValues<Ontology>;
    allowedObjectTypeProperties: Record<string, readonly string[]>;
    /**
     * Projects object/property/link/action/query visibility from the resolved
     * authorization policy. Otherwise the full schema is retained while action
     * parameters and logic are still projected.
     */
    filterSchemaByAuthorization?: boolean;
    visibleActionTypes?: readonly string[] | "all";
    visibleQueryFunctionTypes?: readonly string[] | "all";
}): OntologyIR;
export declare function applyFixedActionParameterValues<Context, Ontology extends OntologyDefinition = OntologyDefinition>(opts: {
    ctx: Context;
    actionType: string;
    parameters: Record<string, unknown>;
    fixedActionParameterValues?: FixedActionParameterValues<Ontology>;
}): Record<string, unknown>;
//# sourceMappingURL=securedOntology.d.ts.map