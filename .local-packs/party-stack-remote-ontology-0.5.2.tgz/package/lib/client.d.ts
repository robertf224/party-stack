import type { CreateLiveOntologyOpts, LiveOntology, OntologyDefinition, OntologyBackendAdapter, OntologyBackendAdapterProvider, OntologyIR, OntologyApplyActionResult } from "@party-stack/ontology";
import { type RemoteOntologyTransport } from "./protocol.js";
export interface OntologyActionRefreshResult {
    status: "ok" | "error" | "aborted";
    objectType: string;
    error?: {
        name: string;
        message: string;
    };
}
export interface OntologyActionRefreshDiagnostics {
    /**
     * Best-effort cache refresh after a confirmed remote write.
     * Never rejects; failures are reported in the resolved results.
     */
    completed: Promise<OntologyActionRefreshResult[]>;
}
export interface OntologyApplyActionClientResult extends OntologyApplyActionResult {
    invalidatedObjectTypes?: string[];
    refresh?: OntologyActionRefreshDiagnostics;
}
export interface CreateRemoteOntologyBackendAdapterOptions {
    ir: OntologyIR;
    transport: RemoteOntologyTransport;
}
export type CreateRemoteOntologyBackendOptions<Context extends Record<string, unknown> = Record<string, unknown>> = {
    transport: RemoteOntologyTransport;
} | {
    createTransport: (ir: OntologyIR, context: Context) => RemoteOntologyTransport | Promise<RemoteOntologyTransport>;
};
export interface CreateRemoteLiveOntologyOptions<Context extends Record<string, unknown> = Record<string, unknown>> {
    transport: RemoteOntologyTransport;
    id?: string;
    runtime?: CreateLiveOntologyOpts<Context>["runtime"];
    persistObjects?: CreateLiveOntologyOpts<Context>["persistObjects"];
    writes?: CreateLiveOntologyOpts<Context>["writes"];
}
export declare function createRemoteOntologyBackendAdapter(opts: CreateRemoteOntologyBackendAdapterOptions): OntologyBackendAdapter;
export declare function createRemoteOntologyBackend<Context extends Record<string, unknown> = Record<string, unknown>>(opts: CreateRemoteOntologyBackendOptions<Context>): OntologyBackendAdapterProvider<Context>;
export declare function createRemoteLiveOntology<Ontology extends OntologyDefinition = OntologyDefinition, Context extends Record<string, unknown> = Record<string, unknown>>(opts: CreateRemoteLiveOntologyOptions<Context>): Promise<LiveOntology<Ontology>>;
//# sourceMappingURL=client.d.ts.map